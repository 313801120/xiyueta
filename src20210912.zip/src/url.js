﻿/*网址处理*/

//处理干净网址
XiyuetaCommon.prototype.handleFileUrl = function(fileUrl) {
    var head = ""; //网址头部协议 如 http://
    var nLen = fileUrl.indexOf("://"); //查的头部协议位置
    if (nLen != -1) { //有头部则处理
        head = fileUrl.substr(0, nLen + 3); //头部内容 如 ftp://
        fileUrl = fileUrl.substr(nLen + 3); //尾部内容
    }
    while (fileUrl.indexOf("//") != -1) { //循环双斜杠
        fileUrl = fileUrl.replace(/\/\//g, '/'); //双斜杠替换单斜杠
    }
    if (fileUrl.indexOf("/./") != -1) fileUrl = fileUrl.replace(/\/.\//g, '/'); //替换网址里面的   /./  为/   因为这个在网址里没有用，一般不用正在原
    if (fileUrl.indexOf("/../") != -1) { //有退出上一级目录的标识 
        var urlArr = []; //定义准备收集网址数组
        var upPosition = 0; //上一级位置
        var splxx = fileUrl.split('/'); //以/分割
        for (var i = 0; i <= splxx.length - 1; i++) {
            var s = splxx[i];
            if (s == "..") { //为退级
                if (upPosition == 0) { //为0则是刚开始检测到第一级  ../
                    upPosition = i - 1;
                } else { //否则为多级  如  ../../
                    upPosition -= 1; //多级的话就在上一级获得的位置上减一位
                }
                if (upPosition >= 0) delete urlArr[upPosition]; //删除上一级
            } else {
                urlArr.push(s); //正常追加到数组
                upPosition = 0; //上一级位置为初始0
            }
        }
        var fileUrl = ""; //网址清空
        for (var i = 0; i <= urlArr.length - 1; i++) { //循环网址数组
            var s = urlArr[i];
            if (urlArr[i] != undefined) { //不为空
                if (fileUrl != "") fileUrl += "/";
                fileUrl += urlArr[i];
            }
        }
    }
    return head + fileUrl; //返回时把头部带上
}

//完整网址  域名+网址合并 如 http://xiyueta.com/a/b/c/    ../../../1.jpg  等于 http://xiyueta.com/1.jpg
XiyuetaCommon.prototype.fullHttpUrl = function(httpurl, url) {
    if (url == undefined) return ""; //url为无效时不处理20210504
    url = url.replace(/\\/g, '/'); //正则替换全部 \为   不要转为小写20210526
    if (url == "" || url == "" || url == "./") return ""; //无效文件路径，则为空退出

    var head = ""; //网址头部协议 如 http://
    var rootDir = ""; //网址主目录
    var thisDir = ""; //当前目录
    var nLen = httpurl.indexOf("://"); //查的头部协议位置
    if (nLen != -1) { //有头部则处理
        head = httpurl.substr(0, nLen + 3); //头部内容 如 ftp://

        var s = httpurl.substr(nLen + 3); //尾部内容
        var nLen = s.lastIndexOf('/'); //从尾部位置提取        
        thisDir = head + s.substr(0, nLen + 1); //当前网址不要后缀文件名

        var nLen = s.indexOf('/'); //从开始位置提取
        rootDir = head + s.substr(0, nLen + 1); //取域名部分

    }

    if (url.substr(0, 2) == "//") { //文件名称前面是// 代表是网址
        url = "http:" + url
    } else if (url.indexOf("://") == -1) { //网址已经是全的,不需要再处理网址完整了
        if (url.substr(0, 1) == "/") { //文件网址里第一个字符是 / 则执行
            url = rootDir + url;
        } else {
            url = thisDir + url;
        }

    }

    return this.handleFileUrl(url); //最后返回时处理下网址干净

}
//获得网址文件名称
XiyuetaCommon.prototype.getUrlFileName = function(fileUrl, sType) {
    if(sType ==undefined)sType = "";//兼容ASP
    if (fileUrl == "" || fileUrl == undefined) return "";
    fileUrl = fileUrl.replace(/\\/g, '/').trim(); //正则替换全部 \为/  并且清空两边空格

    var splxx = fileUrl.split("/");
    var fileName = splxx[splxx.length - 1]; //提取文件名
    var fileStart = ""; //文件名开始部分   如 fname
    var fileType = ""; //文件名类型  如 jpg
    if (fileName.indexOf("?") != -1) { //文件名里有? 则直接处理成文件名称
        fileName = fileName.substr(0, fileName.indexOf("?"));
        // fileName = this.setFileName(fileName);//处理文件名里不能在电脑里创建的特殊字符
    }
    if (fileName.indexOf(".") != -1) { //文件名有文件类型部分
        var nLen = fileName.lastIndexOf(".");
        fileStart = fileName.substr(0, nLen); //提取文件开始部分
        //fileStart=this.setFileName(fileStart)//让文件名可以在本地创建出来
        fileType = fileName.substr(nLen + 1).toLowerCase(); //提取文件类型
    }
    if (sType == "image") { //图片文件类型
        if (fileType == "") {
            fileName += ".jpg"; //文件名后加后缀.jpg
        } else {
            if (("|bmp|jpg|jpeg|gif|png|").indexOf('|' + fileType + '|') == -1) { //不是图片后缀 则替换后缀
                fileName = fileStart + ".jpg";
            }

        }
    } else if (sType == "css") { //CSS文件类型
        if (fileType == "") {
            fileName += ".css"; //文件名后面加后缀.css
        } else {
            if (("|css|").indexOf('|' + fileType + '|') == -1) { //不是css后缀 则替换后缀
                fileName = fileStart + ".css";
            }

        }
    } else if (sType == "js") { //JS文件顾炎武
        if (fileType == "") {
            fileName += ".js"; //文件名后加后缀.js
        } else {
            if (("|js|").indexOf('|' + fileType + '|') == -1) { //不是js后缀 则替换后缀
                fileName = fileStart + ".js";
            }

        }
    } else {
        fileName = fileStart + "." + fileType //默认
    }
    return fileName;
}

//文件命名规则
XiyuetaCommon.prototype.setFileNameA = function(fileName) {
    fileName = fileName.replace(/\\/g, 'pie'); //替换 撇
    fileName = fileName.replace(/\//g, 'la'); //替换空格 揦
    fileName = fileName.replace(/:/g, 'maohao'); //替换 ：
    fileName = fileName.replace(/\*/g, 'xin'); //替换空格 星
    fileName = fileName.replace(/\?/g, 'wen'); //替换 ？
    fileName = fileName.replace(/"/g, 'yinhao'); //替换 “
    fileName = fileName.replace(/</g, 'zou'); //替换 左
    fileName = fileName.replace(/>/g, 'you'); //替换 右
    fileName = fileName.replace(/\|/g, 'heng'); //替换 横
    fileName = fileName.replace(/\./g, 'juhao'); //替换 。
    fileName = fileName.replace(/,/g, 'douhao'); //替换 ，

    fileName = fileName.replace(/&nbsp;/g, ' '); //替换空格
    fileName = fileName.replace(/&quot;/g, 'shuang'); //替换双引号 
    fileName = fileName.replace(/\n/g, ''); //替换换行
    return fileName;
}

//检测是否为网址
XiyuetaCommon.prototype.checkUrl = function(url) {
    if(url ==undefined)url = "";//兼容ASP

    var regular = /^\b(((https?|ftp):\/\/)?[-a-z0-9]+(\.[-a-z0-9]+)*\.(?:com|edu|gov|int|mil|net|org|biz|info|name|museum|asia|coop|aero|[a-z][a-z]|((25[0-5])|(2[0-4]\d)|(1\d\d)|([1-9]\d)|\d))\b(\/[-a-z0-9_:\@&?=+,.!\/~%\$]*)?)$/i
    if (regular.test(url)) {
        return true;
    } else {
        return false;
    }

}

//获得域名
XiyuetaCommon.prototype.getDomain = function(url) {
    if (typeof(url) != "string") return "";
    if (url.indexOf('//') > -1) {
        var st = url.indexOf("//", 1);
        var _domain = url.substring(st + 1, url.length);
        var et = _domain.indexOf("/", 1);
        _domain = _domain.substring(1, et);
        return _domain;
        // strs = _domain.split(".");
        // return strs[strs.length - 2] + "." + strs[strs.length - 1];
    }
    return "";
}