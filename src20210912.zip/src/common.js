﻿ /*!
 * xiyueta JavaScript Library v1.2.6
 * http://xiyueta.com/
 * 兴趣是最好的老师，模仿是最好的学习
 */

// 公共类 xiyueta.js和xiyueta.css.js共用 常用类放到这里面20210429
function XiyuetaCommon() { //常用公共类
    //复制N次
    this.copyStr = function(str, n) {
        var c = "";
        for (var i = 1; i <= n; i++) {
            c += str;
        }
        return c;
    }
    //计算字符大小
    this.bystesLength = function(str) {
        var count = 0;
        for (var i = 0; i < str.length; i++) {
            if (str.charCodeAt(i) > 255) {
                count += 2;
            } else {
                count++;
            }
        }
        return count;
    }
    //js 根据文件大小换算合适单位，并保留两位小数 
    this.getFileSize = function(fileByte) {
        var fileSizeByte = fileByte;
        var fileSizeMsg = "";
        if (fileSizeByte < 1048576) fileSizeMsg = (fileSizeByte / 1024).toFixed(2) + "KB";
        else if (fileSizeByte == 1048576) fileSizeMsg = "1MB";
        else if (fileSizeByte > 1048576 && fileSizeByte < 1073741824) fileSizeMsg = (fileSizeByte / (1024 * 1024)).toFixed(2) + "MB";
        else if (fileSizeByte > 1048576 && fileSizeByte == 1073741824) fileSizeMsg = "1GB";
        else if (fileSizeByte > 1073741824 && fileSizeByte < 1099511627776) fileSizeMsg = (fileSizeByte / (1024 * 1024 * 1024)).toFixed(2) + "GB";
        else fileSizeMsg = "文件超过1TB";
        return fileSizeMsg;
    }
}