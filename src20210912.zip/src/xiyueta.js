 /*!
  * xiyueta JavaScript Library v1.2.9
  * http://xiyueta.com/
  * 兴趣是最好的老师，模仿是最好的学习
  * xiyueta可以在web,asp,nodejs里使用，要做到兼容，不能用let，不能用私有函数{()}，定义函数不能加默认值
  */

 //xiyueta让HTML文档遍历和操作等工作变得更加简单 创建于20210422
 var _XIYUETA = function(html) {
     "use strict"; //严格模式
     if (html == undefined) html = ""; //判断为无效则为空
     this.htmlSource = html; //html源内容
     this.htmlArr = []; //html结构数组
     this.lv = 0; //HTML结构最后等级，来判断标签是否正确20210818
     this.common = new XiyuetaCommon();
     this.config = {
         version: "1.2.9-1",
         httpurl: "",
         serverurl: "/api/downWeb/default.asp", //服务器地址
         jsdir: "js/",
         cssdir: "css/",
         imagesdir: "images/"
     };
     this.tplConfig = { //网页生成模板配置20210517
         type: "xiyuetacms",
         item: 4 //提取项为大于设定值时，则生成模板
     }

     //HTML解析  20210507 修改 parser(解析器)=parse(解析)
     this.parseHTML = function(inputHtml) {
         if (inputHtml != undefined) this.htmlSource = inputHtml, this.htmlArr = []; //传入HTML不为空则替换html源内容
         var s = ""; //字符
         var upS = "" //上一级字符
         var lableName = ""; //标签名称
         var html = ""; //字符内容
         var upHtml = ""; //上一级字符内容
         var isLabel = false //是否为标签
         var isLabelName = false //是否为标签名称 
         var isEndLabel = false //是否为开始或结束标签 <ul>或</ul>
         var isNode = false //为注释
         var isASP = false //ASP程序
         var lv = 0; //层级

         for (var i = 0; i <= this.htmlSource.length - 1; i++) { //逐个循环html源内容
             upS = s;
             s = this.htmlSource.substr(i, 1);

             if (isLabel) { //为标签 如<a href='1.asp'>   第二步
                 html += s; //html累加标签
                 if (isNode) { //注释为真处理部分
                     if (s == ">" && html.substr(-3, 3) == "-->") { //为注释结束
                         isNode = false; //注释为假
                         isLabel = false; //标签为假
                         isEndLabel = false; //标签结果为假
                         this.htmlArr.push({
                             lv: lv + 1,
                             label: '!--',
                             upHtml: upHtml,
                             downHtml: "",
                             html: html,
                             tagpair: 1 //为单标签
                         }) //注释写入数组   标签为!--
                         html = "", upHtml = "";
                     }

                 } else if (isLabelName && html == "<" + "!--") { //为注释   !-- 注释内容 -- 分开写是在asp里会报错20210824
                     isNode = true;

                 } else if (isASP) { //为ASP结束
                     if (s == ">" && html.substr(-2, 2) == "%>") { //为ASP程序结束
                         isASP = false; //ASP为假
                         isLabel = false; //标签为假
                         isEndLabel = false; //标签结果为假
                         this.htmlArr.push({
                             lv: lv + 1,
                             label: '<%',
                             upHtml: upHtml,
                             downHtml: "",
                             html: html,
                             tagpair: 1 //为单标签
                         }) //注释写入数组   标签为!--
                         html = "", upHtml = "";
                     }
                 } else if (isLabelName && html == "<%") { //为ASP开始
                     isASP = true;



                 } else if (s == " " && isLabelName) { //提取标签名 空格为第一种方式  <a 提取成 a  第三步
                     isLabelName = false

                 } else if (s == ">") { //标签结束 提取标签名第二种方式   第四步
                     isLabelName = false; //是标签名称为假
                     isLabel = false; //是标签为假

                     var tagpair = 2 //标签对 默认为双 是单标签还是又标签
                     if (lableName.substr(0, 1) == '/') { //  为结束标签  /div  
                         isEndLabel = true;
                     } else {
                         lv++; //等级加一 如 <ul>
                         if (lableName.substr(-1, 1) == '/' || ("|br|hr|img|link|meta|param|input|!doctype|rect|line|col|").indexOf("|" + lableName.toLowerCase() + "|") != -1) { //单标签  rect，line是svg里
                             isEndLabel = true; //为单标签，后面需要减1层级
                             tagpair = 1; //为单标签
                             lableName = lableName.replace(/\//g, '').trim(); //单标签改完整20210506  如 br/ 改成 br
                         }
                     }
                     var lc_lableName = lableName.toLowerCase(); //转小写
                     this.htmlArr.push({
                         lv: lv,
                         label: lc_lableName,
                         upHtml: upHtml,
                         downHtml: "",
                         html: html,
                         tagpair: tagpair
                     }) //追加数组 

                     html = "", upHtml = ""; //清空html和上一级html

                     if (isEndLabel) { //结束标签
                         lv--; //等级减一 如 </ul>或<br>等单标签
                         isEndLabel = false; //开始找新标签了，结束标签就为假了
                     }
                     if (lc_lableName == "script") { //为jvascript标签 script
                         var c = this.htmlSource.substr(i + 1).toLowerCase();
                         var n = c.indexOf('</' + 'script>'); //搜索 script结束标签块
                         html = this.htmlSource.substr(i + 1, n); //直接切割script代码部分
                         i += n; //i位置直接累加
                     }else if (lc_lableName == "style") { //为style标签 style
                         var c = this.htmlSource.substr(i + 1).toLowerCase();
                         var n = c.indexOf('</' + 'style>'); //搜索 style结束标签块
                         html = this.htmlSource.substr(i + 1, n); //直接切割script代码部分
                         i += n; //i位置直接累加
                     } else if (lc_lableName == "textarea") { //标签 textarea 追加20210808
                         var c = this.htmlSource.substr(i + 1).toLowerCase();
                         var n = c.indexOf('</' + 'textarea>'); //搜索 textarea结束标签块
                         html = this.htmlSource.substr(i + 1, n); //直接切割textarea代码部分
                         i += n; //i位置直接累加
                     } else if (lc_lableName == "pre") { //标签 pre 追加20210911 
                         var c = this.htmlSource.substr(i + 1).toLowerCase();
                         var n = c.indexOf('</' + 'pre>'); //搜索 pre结束标签块
                         html = this.htmlSource.substr(i + 1, n); //直接切割pre代码部分
                         i += n; //i位置直接累加
                     }




                 }
                 if (isLabelName) lableName += s; //标签名称累加



             } else if (s == "<") { //标签开始      第一步
                 var nextS = this.htmlSource.substr(i + 1, 1).toLowerCase();
                 if ('abcdefghijklmnopqrstuvwxyz!/%?'.indexOf(nextS) != -1) { // 处理小于箭头的特殊处理 %?为asp php  如 <</span>   20210530 
                     upHtml = html; //保留上一级内容
                     downHtml: "";
                     html = s; //html开始记录
                     isLabel = true
                     isLabelName = true;
                     isEndLabel = false; //是开始标签还是结束标签  <ul>或</ul>
                     lableName = ""; //标签名为空
                 } else {
                     html += s;
                 }
             } else { //html内容累加
                 html += s; //html累加
             }
         }
         if (html != "") { //最后html不为空则追加
             this.htmlArr.push({
                 lv: lv,
                 label: '',
                 upHtml: "",
                 downHtml: "",
                 html: html
             })
         }
         this.lv = lv;
     }

     //获得标签参数值或赋值 如 <p class='name'>  class,name
     this.handleLabelParam = function(obj, param, value, isDel) { //操作对象，参数名称
         if (isDel == undefined) isDel = false; //删除当前这个参数元素，默认为假
         if (value == undefined) { //赋值为无值时则为 获得参数值
             if (obj[param] != undefined) return obj[param]; //参数属性存在则直接输出参数值   
         } else {
             value = value.toString(); //转字符类型 当value为数字类型0时，则不赋值20210808
         }
         var n = obj.label.length + 1; //从标签名后开始循环 <div class='xx'> 从每四个位置循环如 class=''>
         var isParam = false; //是否为参数
         var paramName = ""; //参数名
         var paramValue = ""; //参数值
         var isValue = false; //是否为内容
         var yinHaoType = ""; //单双引号类型
         var isYinHao = false; //是否为引号  有的参数没有单双引号 如 <a href=1.jpg>
         var isValidYinHao = true; //是否有效引号，有时可能为空 如 <a name=xx>  
         var nStartPosition = 0; //参数值开始位置
         var paramNameStart = 0; //参数名开始位置20210807
         var isLanguage = false; //参数值里穿插各种语言 如asp,php
         for (var i = n; i <= obj.html.length - 1; i++) { //循环标签串 如 <a href='1.jpg'>
             var s = obj.html.substr(i, 1);
             if (isValue) { //提取参数值为真   第三步
                 if (isYinHao) { //单双引号为真  第五步
                     if (isLanguage) { //为语言20210513
                         if (s == ">") isLanguage = false; //语言结束
                         paramValue += s;
                     } else if (s == yinHaoType || s == ">") { //当前字符和引号相等或在标签最后   第七步
                         paramName = paramName.toLowerCase(); //标签名转小写
                         obj[paramName] = paramValue; //参数值写对数据里，下次就不用再找了
                         isValue = false; //参数值为假
                         isYinHao = false; //单双引号为假
                         yinHaoType = ""; //单双引号为空
                         if (param == paramName) { //当前标签参数名与搜索参数名相等 则处理查找和替换
                             if (value == undefined) { //为查找
                                 return paramValue; //找到指值则退出
                             } else { //为替换
                                 if (value == "") { //为删除
                                     var head = obj.html.substr(0, paramNameStart - 1); //参数内容开始位置，+1去除前面单双引号
                                     var foot = obj.html.substr(i + 1); //参数内容以后内容
                                     obj.html = head + foot; //替换新内容
                                 } else { //为替换
                                     var nStart = nStartPosition; //参数值前面部分
                                     var nEnd = nStartPosition + paramValue.length; //参数值后面部分
                                     if (isValidYinHao) { //为有效的单双引号 修复于20210428
                                         nStart++;
                                         nEnd++;
                                     }
                                     var head = obj.html.substr(0, nStart); //参数内容开始位置，+1去除前面单双引号
                                     var foot = obj.html.substr(nEnd); //参数内容以后内容
                                     obj.html = head + value + foot; //替换新内容
                                 }

                                 obj[paramName] = value; //更新对象里的属性值
                                 return obj; //找到返回对应并退出

                             }
                         } else if (s == ">") { //没有参数名 字符在最后 则处理  针对 <a href=xx></a> 它没有单双引号，这种需要在这里处理下  第二种
                             if (value != undefined) { //为写入
                                 if (value != "") { //没有找到要替换参数名，则不为空时追加20210827更进
                                     obj.html = obj.html.substr(0, obj.html.length - 1) + " " + param + '="' + value + '">'; //最后没有这个参数时，追加默认参数名与参数值
                                 }
                                 obj[param] = value; //追加参数值
                                 return true; //退出
                             }
                         }

                     } else if (s == "<") { //为语言 如asp<% php<?
                         isLanguage = true;
                         paramValue += s;

                     } else { //第六步
                         paramValue += s;
                     }



                 } else if (s == '"' || s == "'") { //第四步 第1种
                     yinHaoType = s; //单双引号
                     isYinHao = true; //引号为真
                     nStartPosition = i; //记录参数值开始位置 
                     isValidYinHao = true; //为有效单双引号

                 } else if (s != " ") { //第四步 第2种
                     yinHaoType = " "; //引号类型为空格
                     isYinHao = true; //引号为真
                     nStartPosition = i; //记录参数值开始位置
                     paramValue = s; //参数值开始累加，因为这里已经开始判断了 如 <a href= 1.asp> 到检测到1的时候，必需把1也算上
                     isValidYinHao = false; //为无效单双引号

                 }



             } else if (s == ">") { //字符在最后 第1种
                 if (value != undefined) { //为替换参数值 对没有找到的参数名处理
                     if (value != "") { //没有找到要替换参数名，则不为空时追加20210827更进
                         obj.html = obj.html.substr(0, obj.html.length - 1) + " " + param + '="' + value + '">'; //最后没有这个参数时，追加默认参数名与参数值
                     }
                     obj[param] = value; //对象追加对应参数名属性
                     return true; //退出
                 } else { //查找  如 <option value="pp" selected >pp</option> 20210815
                     paramName = paramName.trim(); //清除两边空格
                     if (param == paramName) { //当前标签参数名与搜索参数名相等 则处理查找和替换
                         if (value != undefined) { //为替换
                             var nParamLen = paramNameStart + paramName.length; //参数值前面部分 
                             var head = obj.html.substr(0, nParamLen); //参数内容开始位置，+1去除前面单双引号
                             var foot = obj.html.substr(nParamLen); //参数内容以后内容
                             obj.html = head + '="' + value + '"' + foot; //替换新内容
                         }
                         return ""; //为查找，因为它只有标签名没有值，则为空。连标签名也没有的则返回undefined 20210815
                     }

                 }

             } else if (isParam) { //参数值为真   第二步
                 if (s == "=") {
                     paramName = paramName.trim(); //清除两边空格，待处理这种 <selected   id="aa">
                     if (paramName.indexOf(" ") != -1) { //中间有空格 则有两个标签连在一样
                         var splxx = paramName.split(" ");
                         paramName = splxx[0];
                         if (param == paramName) { //当前标签参数名与搜索参数名相等 则处理查找和替换
                             if (value != undefined) { //为替换
                                 var head = obj.html.substr(0, nParamLen); //参数内容开始位置，+1去除前面单双引号
                                 var foot = obj.html.substr(nParamLen); //参数内容以后内容
                                 obj.html = head + '="' + value + '"' + foot; //替换新内容
                             }
                             return ""; //为查找，因为它只有标签名没有值，则为空。连标签名也没有的则返回undefined 20210815
                         }
                     }
                     isParam = false; //找参数名为假
                     isValue = true; //找参数值为真
                     paramValue = ""; //开始收集参数内容 初始化
                     yinHaoType = ""; //单双引号 初始化
                 } else { //参数名不收录空格 
                     paramName += s;
                 }
             } else if (s != " ") { //为找到参数名称开始第一个字符了   第一步
                 isParam = true; //找到参数名，参数值为真
                 paramName = s; //参数名第一个字符
                 paramNameStart = i; //参数名开始位置20210807
             }
         }
         return undefined;
     }


     //获得文档结构  逻辑修复20210425  如：xiyueta("div li:eq(1)")
     this.getDocument = function(config, x, y, isSub) { //isSub为搜索子集 如  ul li a 为什么不这样写isSub = false 因为在ASP里这种不可以
         if (config == undefined) config = ""; //默认值，这种写是为了兼容在ASP里使用
         if (isSub == undefined) isSub = false; //默认值，这种写是为了兼容在ASP里使用

         if (this.htmlArr.length == 0) { //没有HTML结构时提示
             console.log("%c 需要先解析一段html文本", 'font-size:14px;color:#FF3300');
             return "";
         }

         if (config.indexOf(",") != -1) {
             var c = "";
             var splstr = config.split(",");
             for (var i = 0; i <= splstr.length - 1; i++) {
                 var s = this.getDocument(splstr[i], x, y, isSub);
                 c += s;
             }
             var list = "";
             var splstr = c.split(",");
             for (var i = 0; i <= splstr.length - 1; i++) {
                 var s = splstr[i];
                 if ((',' + list + ',').indexOf(',' + s + ',') == -1) {
                     if (list != "") list += ",";
                     list += s;
                 }
             }
             if (list != "") list = "," + list;
             return list;
         }


         config = config.trim(); //清除两边空格，为了解决这种  div    a   多级时中间多个空格
         if (config == "") return ""; //没有内容为空退出20210814
         if (x == undefined) x = 0; //循环开始位置
         if (y == undefined) y = this.htmlArr.length - 1; //循环结束位置
         var lableName = ""; //标签名称
         var nFocus = -1.1; //定位位置从0开始算  如:eq(1) 为第二条
         var configEnd = ""; //配置多级最后跟字符
         var paramName = ""; //参数名
         var paramValue = ""; //参数值
         var paramAction = ""; //参数动作，对比时用到 [name|NOUL=xx]中的NOUL是不区分大小写
         var c = "";

         //处理这种情况 xiyueta("div[class='footer animated fadeInUp']")  20210511
         if (config.indexOf("'") != -1 || config.indexOf('"') != -1) {
             var isYingHao = false; //单双引号
             var c = "";
             for (var i = 0; i <= config.length; i++) {
                 var s = config.substr(i, 1);

                 if (isYingHao == false && (s == "'" || s == '"')) { //=false  出错，是双等号 要认真20210515
                     isYingHao = true;
                     s = "";
                 } else if (isYingHao == true) { //=true  出错，是双等号 要认真20210515
                     if (s == " ") {
                         s = "-Space-"; //代表空格 后面会以空格切割处理多级
                     } else if (s == "'" || s == '"') {
                         isYingHao = false;
                         s = "";
                     }
                 }
                 c += s;
             }
             config = c; //替换
         }
         var nLen = config.indexOf(" "); //多级 用这种方法处理多层20210513
         if (nLen != -1) { //为多级
             configEnd = config.substr(nLen + 1).trim(); //多级后面待处理 清除两边空格 
             config = config.substr(0, nLen);
         }

         var nLen = config.indexOf(":eq(");
         if (nLen != -1) { //有参数:eq(0)  指定索引
             var s = config.substr(nLen + 4);
             var nEndLen = s.indexOf(")");
             nFocus = s.substr(0, nEndLen);
             if (nFocus != "") nFocus = parseInt(nFocus); //字符转数字
             config = config.substr(0, nLen); //重复处理下 如 li:eq(0)  =  li  不用这种，先全部获得再找20210815
         }

         var nLen = config.indexOf("[");
         if (nLen != -1) { //有参数[name=22]  选择具有指定属性且其值完全等于某个特定值的元素。
             var s = config.substr(nLen + 1);
             var nEndLen = s.indexOf("]");
             s = s.substr(0, nEndLen);

             var splA = s.split("=")
             paramName = splA[0]; //查找参数名
             paramValue = splA[1].replace(/-Space-/g, ' ');; //查找参数值 替换恢复 空格20210511
             if (paramName.indexOf("|") != -1) {
                 var splB = paramName.split("|");
                 paramName = splB[0];
                 paramAction = splB[1]; //参数动作
             }
             config = config.substr(0, nLen); //重复处理下 如 li:eq(0)  =  li
         }

         if (config.substr(0, 1) == "#") { //ID选择器，只取第一条，就结束20210814
             if (nFocus > 0) return ""; // 这种 #nav:eq(1) 直接返回空，和jQuery里保持一致
             nFocus = 0;
         }

         //处理对象后面加点类名 如  li.myclas 20210904
         var className = "";
         var nLen = (config.substr(1)).lastIndexOf(".");
         if (nLen >= 0) { //未找到为-1
             var sTemp = config;
             config = sTemp.substr(0, nLen + 1); //前面截取时去一位
             className = sTemp.substr(nLen + 2); //前面截取时去一位 +1

         }
         c = this.serchDocument(config, x, y, paramName, paramValue, paramAction, className); //获得搜索列表

         if (c != "" && nFocus != -1.1) { //获得指定位置

             var splstr = c.split(",");
             if (nFocus < 0) {
                 var index = splstr.length + nFocus;
                 c = splstr[index];
             } else {
                 c = splstr[nFocus + 1];
             }
             if (c != "") c = ',' + c;
         }
         if (configEnd != "" && c != "") {
             var splstr = c.split(",");
             c = ""; //清空
             for (var i = 1; i <= splstr.length - 1; i++) {
                 var s = splstr[i];
                 var x, y;
                 if (s.indexOf("|") != -1) { //双标签
                     var splxx = s.split("|");
                     x = parseInt(splxx[0]) + 1, y = parseInt(splxx[1]) - 1; //+1-1是排除自身
                     c += this.getDocument(configEnd, x, y, true);
                 }

             }
         }
         if (isSub == false) { //为假则为最后处理完后20210816
             var splstr = c.split(",");
             c = ""; //清空
             for (var i = 1; i <= splstr.length - 1; i++) {
                 var s = splstr[i];
                 if ((',' + c + ',').indexOf(',' + s + ',') == -1) {
                     c += "," + s;
                 }
             }
         }
         return c;
     }
     //搜索Document20210815
     this.serchDocument = function(lableName, x, y, paramName, paramValue, paramAction, className) { //为什么不这样写paramAction = "" 因为在ASP里会报错20210824
         if (paramName == undefined) paramName = ""; //这样写是为了在ASP里不报错20210824
         if (paramValue == undefined) paramValue = ""; //参数值
         if (paramAction == undefined) paramAction = ""; //参数动作
         if (className == undefined) className = ""; //对象类名称  如  li.myclass


         var isTxt = false; //是否累加标签之间的内容 如 <div> a <br><a href=''>1</a> b </div>
         var c = ""; //输出内容 如 ,1|3,6|7
         var lv = 0; //层级
         var nLabelStart = 0; //记录标签开始位置 
         var isTrue = false; //是否为真

         for (var i = x; i <= y; i++) { //从指定两个位置循环
             var obj = this.htmlArr[i]
             if (obj != undefined) {
                 if (isTxt && this.checkEndSelector(obj, lableName) && lv == obj.lv) { //结束标签
                     isTxt = false; //双标签判断时用到，为假
                     if (isTrue) c += "|" + i; //为真则累加，加|以双标签需要判断
                     isTrue = false; //找到那真则为初始默认假
                     c += this.serchDocument(lableName, nLabelStart + 1, i, paramName, paramValue, paramAction); //子标签  i是循环y值，不能减1 因为循环时候是小于而不是等于

                 } else if (this.checkStartSelector(obj, lableName, className) && isTxt == false) { //开始标签   
                     if (obj.tagpair == 2) { //双标签
                         isTxt = true; //双标签取中间内容
                         lv = obj.lv;
                     }
                     nLabelStart = i; //记录标签开始位置

                     var isAdd = true; //是否记录找到值
                     //判断这种 [class=name]
                     if (paramName != "") { //有查找参数名，则判断参数值是否相等 
                         var s = this.handleLabelParam(obj, paramName); //获得参数值 
                         if (paramAction == "NOUL") s = s.toLowerCase(); //动作NOUL为不区分大小写 则值转小写，好与参数值对比
                         if (s != paramValue) {
                             isAdd = false; //不等为假就不累加了
                         }
                     }

                     //[class=a]:eq(1)都符合则处理
                     if (isAdd) {
                         c += "," + i; //,为分割查找条数
                         if (obj.tagpair == 2) {
                             isTrue = true; //双标签则为真 累加到结束标签里累加
                         }
                     }
                 }

             }
         }
         return c;
     }
     //检测开始选择器20210814
     this.checkStartSelector = function(obj, lableName, checkClassName) {
         if (obj.label == "") return false; //标签为空则退出，为那个最后一个为内容数组
         var newLableName = lableName + " ";
         var obj1Label = obj.label.substr(0, 1); //当前标签取一位
         var find1Label = lableName.substr(0, 1); //查的配置取一位
         if (obj1Label == '/') return false; //标称名第一个字符为/为结束标签，则退出

         if (find1Label == "*") { //全部配置则为真退出 find1Label=取一位来判断，防多级时出错             
             if (checkClassName != "") { //处理对象后面加点类名 如  li.myclas 20210904
                 var className = this.handleLabelParam(obj, "class");
                 if (className == undefined) return false;
                 return (' ' + className + ' ').indexOf(' ' + checkClassName + ' ') != -1 ? true : false;
             } else { return true; }

         } else if (find1Label == "#") { //ID查找
             var findParamName = lableName.substr(1, newLableName.indexOf(" ") - 1);
             var id = this.handleLabelParam(obj, "id");
             if (id == findParamName) {
                 if (checkClassName != "") { //处理对象后面加点类名 如  li.myclas 20210904
                     var className = this.handleLabelParam(obj, "class");
                     if (className == undefined) return false;
                     return (' ' + className + ' ').indexOf(' ' + checkClassName + ' ') != -1 ? true : false;
                 } else { return true; }
             }

         } else if (find1Label == ".") { //class查找
             var findParamName = lableName.substr(1, newLableName.indexOf(" ") - 1);
             var className = ' ' + this.handleLabelParam(obj, "class") + ' ';
             if (className.indexOf(' ' + findParamName + ' ') != -1) { //修复于 20210909 以#id查找一致
                 if (checkClassName != "") { //处理对象后面加点类名 如  li.myclas 20210904
                     var className = this.handleLabelParam(obj, "class");
                     if (className == undefined) return false;
                     return (' ' + className + ' ').indexOf(' ' + checkClassName + ' ') != -1 ? true : false;
                 } else { return true; }
             }

         } else if (obj.label + " " == lableName.substr(0, obj.label.length + 1) + " ") { //标签查找
             if (checkClassName != "") { //处理对象后面加点类名 如  li.myclas 20210904
                 var className = this.handleLabelParam(obj, "class");
                 if (className == undefined) return false;
                 return (' ' + className + ' ').indexOf(' ' + checkClassName + ' ') != -1 ? true : false;
             } else { return true; }
         }
         return false;
     }
     //检测结束选择器20210814
     this.checkEndSelector = function(obj, lableName) {
         var obj1Label = obj.label.substr(0, 1); //当前标签取一位
         var find1Label = lableName.substr(0, 1); //查的配置取一位
         if (find1Label == "*") return true; //全部配置则为真退出 find1Label=取一位来判断，防多级时出错
         if (find1Label == "#" || find1Label == ".") { //ID查找
             return true;
         } else if (obj.label == "/" + lableName.substr(0, obj.label.length - 1)) {
             return true;
         }
         return false;
     }



     //获得文本(完整版) 20210422完善 20210424改进
     this.getText = function(lableName, x, y) {

         // alert(lableName)
         if (typeof(lableName) == "object") { //查的参数为对象则处理20210802
             this.domList = "," + lableName.x
             if (lableName.x != lableName.y) this.domList += "|" + lableName.y;
             lableName = "";
         } else {
             lableName = lableName.trim(); //清除两边空格
         }
         var c = "";
         var s = this.domList; //用已存在20210806
         if (this.domList == undefined) {
             s = this.getDocument(lableName, x, y); //查找标签对应排序如  ,1|3,6|9             
         }
         var splstr = s.split(",");
         for (var i = 1; i <= splstr.length - 1; i++) {
             var s = splstr[i];
             if (s.indexOf("|") != -1) { //只操作双标签，因为单标签没有内容部分
                 var splxx = s.split("|");
                 for (var j = parseInt(splxx[0]) + 1; j <= splxx[1]; j++) {
                     if (this.htmlArr[j] != undefined) c += this.htmlArr[j].upHtml; //累加双标签内容部分  判断加于20210516
                 }
             }
         }
         return c;
     }


     //获得HTML 只获得第一级  等测试div[name=a]eq:(1)  不包换当前标签
     this.getHtml = function(lableName, x, y, action) {
         if (action == undefined) action = "";
         if (action != '') action = '|' + action + '|'; //为空则追加||
         if (typeof(lableName) == "object") { //查的参数为对象则处理20210802
             this.domList = "," + lableName.x
             if (lableName.x != lableName.y) this.domList += "|" + lableName.y;
             lableName = "";
         } else {
             lableName = lableName.trim(); //清除两边空格
         }
         var c = "";
         var s = this.domList; //用已存在20210806
         if (this.domList == undefined) {
             s = this.getDocument(lableName, x, y); //查找标签对应排序如  ,1|3,6|9             
         }
         var splstr = s.split(",");
         if (splstr.length < 2) return undefined; //小于2则就是1了，默认为一，所以为空 退出 返回undefined与jQuery里保持一致20210815
         var s = splstr[1]; //获得第一条,也只处理一条

         if (s.indexOf("|") != -1) {
             var splxx = s.split("|");
             var x = parseInt(splxx[0]);
             var y = parseInt(splxx[1]);
             for (var j = x; j <= y; j++) { //循环，除双标签开始这一条
                 var obj = this.htmlArr[j];
                 if (obj) {
                     if (j > x) {
                         if (action.indexOf('doc') == -1) { //为结构为假，当动作里有doc结构时，则显示结构 20210515
                             c += obj.upHtml;
                         }
                     }
                     if (action.indexOf('all') != -1) { //为全部
                         if (action.indexOf('label') != -1) { //为标签
                             c += "<" + obj.label + ">";
                         } else {
                             c += obj.html; //标签块
                         }
                     } else if (j > x && j < y) { //除标签开始与结束外
                         if (action.indexOf('doc') != -1 && obj.label != "!--") {
                             if (action.indexOf('label') != -1) { //为标签
                                 c += "<" + obj.label + ">";
                             } else {
                                 c += obj.html; //标签块
                             }
                         } else if (action == "") { //没有动作的时候显示标签块20210519
                             c += obj.html;
                         }
                     }
                 }
             }
         } else if (s != "") { //为单标签
             if (action.indexOf('all') != -1) { //为all则显示单标签的标签块
                 if (action.indexOf('label') != -1) { //为标签
                     c += "<" + obj.label + ">";
                 } else {
                     c = this.htmlArr[s].html;
                 }
             }
         }
         return c;
     }

     //设置Htlm(简洁版)
     this.setHtml = function(lableName, x, y, value, action) {
         //操作对象 追加20210505
         if (typeof(lableName) == "object") {
             s = "," + lableName.x + "|" + lableName.y;
         } else {
             var s = this.domList; //用已存在20210806
             if (this.domList == undefined) {
                 s = this.getDocument(lableName, x, y); //查找标签对应排序如  ,1|3,6|9             
             }
         }

         var splstr = s.split(",");
         for (var i = 1; i <= splstr.length - 1; i++) {
             var s = splstr[i];
             if (s.indexOf("|") != -1) { //双标签 只处理双标签
                 var splxx = s.split("|");
                 var x = parseInt(splxx[0]);
                 var y = parseInt(splxx[1]);
                 for (var j = x; j <= y; j++) {
                     var obj = this.htmlArr[j];
                     if (obj) { //对象存在
                         if (j == x) { //开始位置
                             if (action == "all") obj.html = ""; //为all时不要结束的html部分
                         } else if (j < y) { //在双标签中间
                             delete this.htmlArr[j]; //删除数组
                         } else if (j == y) { //结束位置
                             obj.upHtml = value; //替换内容部分
                             if (action == "all") obj.html = ""; //为all时不要开始的html部分
                         }
                     }
                 }
             }
         }
         return this;
     }
     //处理CSS参数 获得或设置
     this.handleCssParam = function(obj, param, value) { //操作对象，参数名称
         var x, y;
         if (value == undefined) { //赋值为无值时则为 获得参数值
             var sAtt = this.attr(obj, x, y, "style");
             if (sAtt == undefined) sAtt = "";
             var cssStyle = "a{" + sAtt + "}"
             var s = $xytcss("a").parse(cssStyle).css(param);
             return s;
         } else {
             value = value.toString(); //转字符类型 当value为数字类型0时，则不赋值20210808
             var sAtt = this.attr(obj, x, y, "style");
             if (sAtt == undefined) sAtt = "";
             var cssStyle = "a{" + sAtt + "}"
             var s = $xytcss("a").parse(cssStyle).css(param, value);
             var css = $xytcss().print();
             css = css.substr(2, css.length - 3);
             this.attr(obj, x, y, "style", css);
         }
     }
     //为每个匹配元素设置一个或多个 CSS 属性 20210822  从attr引用改进过来，以后把两个合并
     this.css = function(lableName, x, y, paramName, setParamValue) { //标签，参数名称  设置参数值
         if (typeof paramName == "object") { //处理参数名为对象是处理20210901
             for (var key in paramName) { //循环对象并赋值CSS
                 this.css(lableName, x, y, key, paramName[key]);
             }
             return this;
         }

         if (paramName == undefined) paramName = ""; //没有参数值 为空退出
         paramName = paramName.trim(); //清空参数名两边空格
         if (paramName == "") return ""; //参数名为空 退出 
         //操作对象 追加20210505
         if (typeof(lableName) == "object") {
             if (setParamValue == undefined) { //查找  
                 return this.handleCssParam(lableName, paramName); //获得参数值 此时lableName为一个对象
             }
             return this.handleCssParam(lableName, paramName, setParamValue); //替换 此时lableName为一个对象
         }

         var s = this.domList; //用已存在20210806
         if (this.domList == undefined) {
             s = this.getDocument(lableName, x, y); //查找标签对应排序如  ,1|3,6|9             
         }
         var splstr = s.split(","); //分割  如 ,1,3|5
         if (setParamValue == undefined) { //查找  只提取第一条 与jquery里保持一致
             var s = splstr[1];
             if (s == undefined) return undefined; //20210530 一条也没有找到，则返回undefined,与jQuery保持一致20210815
             var splxx = s.split("|");
             var obj = this.htmlArr[splxx[0]]; //获得对应HTML索引对象
             var s = this.handleCssParam(obj, paramName); //获得参数值 
             return s; //返回 查找到的标签参数值
         }
         for (var i = 1; i <= splstr.length - 1; i++) { //替换
             var s = splstr[i];
             if (s.indexOf("|") != -1) { //双标签
                 var splxx = s.split("|");
                 var obj = this.htmlArr[splxx[0]]; //提取双标签的开始标签块                     
                 this.handleCssParam(obj, paramName, setParamValue); //替换参数值                     
             } else { //单标签
                 var obj = this.htmlArr[s];
                 this.handleCssParam(obj, paramName, setParamValue); //替换参数值                         
             }
         }
         return undefined;


     }
     //获得参数值或设置参数值  改进20210505
     this.attr = function(lableName, x, y, paramName, setParamValue) { //标签，参数名称  设置参数值
         if (typeof paramName == "object") { //处理参数名为对象是处理20210901
             for (var key in paramName) { //循环对象并赋值CSS
                 this.attr(lableName, x, y, key, paramName[key]);
             }
             return this;
         }

         if (paramName == undefined) paramName = ""; //没有参数值 为空退出
         paramName = paramName.trim(); //清空参数名两边空格
         if (paramName == "") return ""; //参数名为空 退出 
         //操作对象 追加20210505
         if (typeof(lableName) == "object") {
             if (setParamValue == undefined) { //查找  
                 return this.handleLabelParam(lableName, paramName); //获得参数值 此时lableName为一个对象
             }
             return this.handleLabelParam(lableName, paramName, setParamValue); //替换 此时lableName为一个对象
         }

         var s = this.domList; //用已存在20210806
         if (this.domList == undefined) {
             s = this.getDocument(lableName, x, y); //查找标签对应排序如  ,1|3,6|9             
         }
         var splstr = s.split(","); //分割  如 ,1,3|5
         if (setParamValue == undefined) { //查找  只提取第一条 与jquery里保持一致
             var s = splstr[1];
             if (s == undefined) return undefined; //20210530 一条也没有找到，则返回undefined,与jQuery保持一致20210815
             var splxx = s.split("|");
             var obj = this.htmlArr[splxx[0]]; //获得对应HTML索引对象
             var s = this.handleLabelParam(obj, paramName); //获得参数值 
             return s; //返回 查找到的标签参数值
         }
         for (var i = 1; i <= splstr.length - 1; i++) { //替换
             var s = splstr[i];
             if (s.indexOf("|") != -1) { //双标签
                 var splxx = s.split("|");
                 var obj = this.htmlArr[splxx[0]]; //提取双标签的开始标签块 
                 this.handleLabelParam(obj, paramName, setParamValue); //替换参数值                     
             } else { //单标签
                 var obj = this.htmlArr[s];
                 this.handleLabelParam(obj, paramName, setParamValue); //替换参数值                         
             }
         }
         return undefined;
     }

     //获取匹配元素集中第一个元素的当前值或设置每个匹配元素的值 20210808
     this.val = function(lableName, x, y, setParamValue) { //标签，参数名称  设置参数值 
         //操作对象 追加20210505
         if (typeof(lableName) == "object") {
             s = "," + lableName.x + "|" + lableName.y;
         } else {
             var s = this.domList; //用已存在20210806
             if (this.domList == undefined) {
                 s = this.getDocument(lableName, x, y); //查找标签对应排序如  ,1|3,6|9             
             }
         }
         var splstr = s.split(","); //分割  如 ,1,3|5
         if (setParamValue == undefined) { //查找  只提取第一条 与jquery里保持一致                 
             var s = splstr[1];
             if (s == undefined) return ""; //20210530
             var splxx = s.split("|");
             var obj = this.htmlArr[splxx[0]]; //获得对应HTML索引对象
             if (obj.label == "textarea") {
                 obj.x = splxx[0]; //对象需要有X位置20210823
                 obj.y = splxx[1]; //对象需要有Y位置20210823
                 return this.getHtml(obj); //内容
             } else if (obj.label == "select") {
                 var newS = this.getDocument("option", obj.x, obj.y); //查找标签对应排序如  ,1|3,6|9              
                 if (newS != "") {
                     var sGetVal;
                     var splstrB = newS.split(",");
                     for (var i = 1; i <= splstrB.length - 1; i++) { //替换
                         var s2 = splstrB[i];
                         if (s2.indexOf("|") != -1) { //双标签
                             var splB = s2.split("|");
                             var newsObj = this.htmlArr[splB[0]];
                             var sSelected = this.handleLabelParam(newsObj, "selected");
                             if (sSelected != undefined || sGetVal == undefined) {
                                 sGetVal = this.handleLabelParam(newsObj, "value");
                             }
                         }
                     }
                     return sGetVal;
                 }
                 return undefined;

             } else {
                 return this.handleLabelParam(obj, "value"); //获得参数值 

             }
         }

         for (var i = 1; i <= splstr.length - 1; i++) { //替换
             var s = splstr[i];
             if (s.indexOf("|") != -1) { //双标签
                 var splxx = s.split("|");
                 var obj = this.htmlArr[splxx[0]]; //提取双标签的开始标签块
                 if (obj.label == "textarea") {
                     obj.x = splxx[0], obj.y = splxx[1];
                     this.setHtml(obj, undefined, undefined, setParamValue);
                 } else if (obj.label == "select") { //这种不替换，和jQuery里一致
                     var newS = this.getDocument("option", obj.x, obj.y); //查找标签对应排序如  ,1|3,6|9              
                     if (newS != "") {
                         var sGetVal;
                         var splstrB = newS.split(",");
                         for (var i = 1; i <= splstrB.length - 1; i++) { //替换
                             var s2 = splstrB[i];
                             if (s2.indexOf("|") != -1) { //双标签
                                 var splB = s2.split("|");
                                 var newsObj = this.htmlArr[splB[0]];
                                 var sVal = this.handleLabelParam(newsObj, "value");
                                 if (sVal == setParamValue) {

                                     this.handleLabelParam(newsObj, "selected", "selected"); //替换参数值

                                 } else {
                                     this.handleLabelParam(newsObj, "selected", null); //替换参数值

                                 }
                             }
                         }
                     }


                 } else {
                     this.handleLabelParam(obj, "value", setParamValue); //替换参数值
                 }
             } else { //单标签 只有input所以只有value一种
                 var obj = this.htmlArr[s];
                 this.handleLabelParam(obj, "value", setParamValue); //替换参数值                         
             }
         }
         return "";
     }

     //遍历HTML对象，为每个匹配的元素执行一个函数。 20210505   待改进，把html text加入
     this.each = function(lableName, x, y, callback) {
         var arr = [];
         lableName = lableName.trim(); //清除两边空格

         var s = this.domList; //用已存在20210806
         if (this.domList == undefined) {
             s = this.getDocument(lableName, x, y); //查找标签对应排序如  ,1|3,6|9             
         }
         var splstr = s.split(",");
         for (var i = 1; i <= splstr.length - 1; i++) {
             var s = splstr[i];
             if (s.indexOf("|") != -1) { //双标签
                 var splxx = s.split("|");
                 var obj = this.htmlArr[splxx[0]];
                 obj.x = parseInt(splxx[0]);
                 obj.y = parseInt(splxx[1]);
                 arr.push(obj);
             } else { //为单标签
                 var obj = this.htmlArr[s];
                 obj.x = parseInt(s);
                 obj.y = parseInt(s);
                 arr.push(obj);

             }
         }
         //处理数组 
         // if (Array.isArray(arr)) {//不用这种，不兼容ASP20210824
         if (typeof arr == "object") {
             for (var i = 0, l = arr.length; i < l; i++) {
                 //出现false即出错情况下出现
                 if (callback.call(arr[i], i, arr[i]) == false) { // 第一个为this对象，第二个为编号,第三个为对象本身，第1和第3一样20210901 
                     break;
                 }
             }
         }
     }

     //移除标签对 20210425
     this.remove = function(lableName, x, y) {
         if (typeof(lableName) == "object") {
             s = "," + lableName.x + "|" + lableName.y;
         } else {
             var s = this.domList; //用已存在20210806
             if (this.domList == undefined) {
                 s = this.getDocument(lableName, x, y); //查找标签对应排序如  ,1|3,6|9             
             }
         }

         if (s == "") return false; //为空则没有找到 删除失败 为假 退出
         var splstr = s.split(",");
         for (var i = 1; i <= splstr.length - 1; i++) {
             var s = splstr[i];
             if (s.indexOf("|") != -1) { //双标签
                 var splxx = s.split("|");
                 var x = parseInt(splxx[0]);
                 var y = parseInt(splxx[1]);
                 for (var j = x; j <= y; j++) {
                     var obj = this.htmlArr[j];
                     if (obj) {
                         if (j == x) { //等于开始标签时，要保存标签上面的内容，所以不能删除这个对象，只能清空html和label标签
                             obj.html = "";
                             obj.label = "";
                         } else {
                             delete this.htmlArr[j]; //删除数组
                         }
                     }
                 }
             } else { //单标签
                 var obj = this.htmlArr[s];
                 if (obj) {
                     obj.html = "";
                     obj.label = "";
                 }
             }
         }
         return true; //为真退出

     }
     //添加标签class样式名称20210807
     this.addClass = function(lableName, x, y, setParamValue) {
         if (setParamValue == undefined) return false; //退出
         setParamValue = setParamValue.trim(); //清除两边空格
         if (setParamValue == "") return false; //退出
         var splParam = setParamValue.split(" "); //数组

         if (typeof(lableName) == "object") {
             s = "," + lableName.x + "|" + lableName.y;
         } else {
             var s = this.domList; //用已存在20210806
             if (this.domList == undefined) {
                 s = this.getDocument(lableName, x, y); //查找标签对应排序如  ,1|3,6|9             
             }
         }


         var splstr = s.split(",");
         for (var i = 1; i <= splstr.length - 1; i++) {
             var s = splstr[i];
             var splxx = s.split("|");
             var obj = this.htmlArr[splxx[0]];
             var className = this.attr(obj, x, y, "class");
             if (className != undefined) {
                 className = className.trim();
             } else {
                 className = "";
             }
             for (var j = 0; j <= splParam.length - 1; j++) {
                 if (splParam[j] != "") {
                     if (className != "") className += " ";
                     className += splParam[j];
                 }
             }
             this.attr(obj, x, y, "class", className); //替换

         }
     }
     //移除标签class样式名称20210807
     this.removeClass = function(lableName, x, y, setParamValue) {
         if (setParamValue == undefined) return false; //退出
         setParamValue = setParamValue.trim(); //清除两边空格
         if (setParamValue == "") return false; //退出
         var splParam = setParamValue.split(" "); //数组

         if (typeof(lableName) == "object") {
             s = "," + lableName.x + "|" + lableName.y;
         } else {
             var s = this.domList; //用已存在20210806
             if (this.domList == undefined) {
                 s = this.getDocument(lableName, x, y); //查找标签对应排序如  ,1|3,6|9             
             }
         }

         var splstr = s.split(",");
         for (var i = 1; i <= splstr.length - 1; i++) {
             var s = splstr[i];
             var splxx = s.split("|");
             var obj = this.htmlArr[splxx[0]];
             var className = this.attr(obj, x, y, "class");
             if (className != undefined) {
                 className = className.trim();
                 className = " " + className + " ";
                 for (var j = 0; j <= splParam.length - 1; j++) {
                     if (splParam[j] != "") {
                         className = className.replace(' ' + splParam[j] + ' ', ' '); //替换
                     }
                 }
                 this.attr(obj, x, y, "class", className.trim()); //替换
             }
         }
     }
     //将HTML结构包裹在匹配元素集中的每个元素周围 20210825
     this.wrap = function(lableName, x, y, sHead, sFoot) {
         if (typeof(lableName) == "object") { //查的参数为对象则处理20210802
             this.domList = "," + lableName.x
             if (lableName.x != lableName.y) this.domList += "|" + lableName.y;
             lableName = "";
         } else {
             lableName = lableName.trim(); //清除两边空格
         }
         var c = "";
         var s = this.domList; //用已存在20210806
         if (this.domList == undefined) {
             s = this.getDocument(lableName, x, y); //查找标签对应排序如  ,1|3,6|9             
         }
         var splstr = s.split(",");
         for (var i = 1; i <= splstr.length - 1; i++) {
             var s = splstr[i];
             if (s.indexOf("|") != -1) { //双标签
                 var splxx = s.split("|");
                 this.htmlArr[splxx[0]].upHtml += sHead;
                 this.htmlArr[splxx[1]].downHtml += sFoot;
             } else { //单标签
                 this.htmlArr[s].upHtml += sHead;
                 this.htmlArr[s].downHtml += sFoot;
             }
         }
         return this;
     }
     //从 DOM 中移除匹配元素集的父元素，将匹配元素留在原处。 20210825
     this.unwrap = function(lableName, x, y) {
         if (typeof(lableName) == "object") { //查的参数为对象则处理20210802
             this.domList = "," + lableName.x
             if (lableName.x != lableName.y) this.domList += "|" + lableName.y;
             lableName = "";
         } else {
             lableName = lableName.trim(); //清除两边空格
         }
         var c = "";
         var s = this.domList; //用已存在20210806
         if (this.domList == undefined) {
             s = this.getDocument(lableName, x, y); //查找标签对应排序如  ,1|3,6|9             
         }
         var splstr = s.split(",");
         for (var i = 1; i <= splstr.length - 1; i++) {
             var s = splstr[i];
             var findLv = 0.1;
             var startI = 0;
             var endI = 0;
             if (s.indexOf("|") != -1) { //双标签
                 var splxx = s.split("|");
                 findLv = this.htmlArr[splxx[0]].lv - 1;
                 startI = parseInt(splxx[0]);
                 endI = parseInt(splxx[1]);
             } else { //单标签
                 var obj = this.htmlArr[s];
                 findLv = obj.lv - 1;
                 startI = endI = parseInt(s);
             }
             // console.log(s, startI + " " + endI)
             // 向上找标签并清空
             for (var j = startI; j >= 0; j--) {
                 var obj = this.htmlArr[j];
                 if (typeof(obj) == "object") {
                     if (this.htmlArr[j].lv == findLv) {
                         obj.html = "";
                         break;
                     }
                 }
             }
             // 向下找标签并清空
             for (var j = endI; j <= this.htmlArr.length - 1; j++) {
                 var obj = this.htmlArr[j];
                 if (typeof(obj) == "object") {
                     if (this.htmlArr[j].lv == findLv) {
                         obj.html = "";
                         break;
                     }
                 }
             }



         }
         return this;
     }
     //在被选元素的结尾插入内容 20210908
     this.append = function(lableName, x, y, value) {
         if (typeof(lableName) == "object") { //查的参数为对象则处理20210802
             this.domList = "," + lableName.x
             if (lableName.x != lableName.y) this.domList += "|" + lableName.y;
             lableName = "";
         } else {
             lableName = lableName.trim(); //清除两边空格
         }
         var c = "";
         var s = this.domList; //用已存在20210806
         if (this.domList == undefined) {
             s = this.getDocument(lableName, x, y); //查找标签对应排序如  ,1|3,6|9             
         }
         var splstr = s.split(",");
         for (var i = 1; i <= splstr.length - 1; i++) {
             var s = splstr[i];
             if (s.indexOf("|") != -1) { //双标签
                 var splxx = s.split("|");
                 this.htmlArr[splxx[1]].upHtml += value;
             } else { //单标签
                 this.htmlArr[s].downHtml += value;
             }
         }
         return this;
     }
     //在被选元素的开头插入内容 20210908
     this.prepend = function(lableName, x, y, value) {
         if (typeof(lableName) == "object") { //查的参数为对象则处理20210802
             this.domList = "," + lableName.x
             if (lableName.x != lableName.y) this.domList += "|" + lableName.y;
             lableName = "";
         } else {
             lableName = lableName.trim(); //清除两边空格
         }
         var c = "";
         var s = this.domList; //用已存在20210806
         if (this.domList == undefined) {
             s = this.getDocument(lableName, x, y); //查找标签对应排序如  ,1|3,6|9             
         }
         var splstr = s.split(",");
         for (var i = 1; i <= splstr.length - 1; i++) {
             var s = splstr[i];
             if (s.indexOf("|") != -1) { //双标签
                 var splxx = s.split("|");
                 this.htmlArr[splxx[0]].html += value;
             } else { //单标签
                 this.htmlArr[s].html += value;
             }
         }
         return this;
     }
     //在被选元素之后插入内容 20210908
     this.after = function(lableName, x, y, value) {
         if (typeof(lableName) == "object") { //查的参数为对象则处理20210802
             this.domList = "," + lableName.x
             if (lableName.x != lableName.y) this.domList += "|" + lableName.y;
             lableName = "";
         } else {
             lableName = lableName.trim(); //清除两边空格
         }
         var c = "";
         var s = this.domList; //用已存在20210806
         if (this.domList == undefined) {
             s = this.getDocument(lableName, x, y); //查找标签对应排序如  ,1|3,6|9             
         }
         var splstr = s.split(",");
         for (var i = 1; i <= splstr.length - 1; i++) {
             var s = splstr[i];
             if (s.indexOf("|") != -1) { //双标签
                 var splxx = s.split("|");
                 this.htmlArr[splxx[1]].downHtml += value;
             } else { //单标签
                 this.htmlArr[s].downHtml += value;
             }
         }
         return this;
     }
     //在被选元素之前插入内容 20210908
     this.before = function(lableName, x, y, value) {
         if (typeof(lableName) == "object") { //查的参数为对象则处理20210802
             this.domList = "," + lableName.x
             if (lableName.x != lableName.y) this.domList += "|" + lableName.y;
             lableName = "";
         } else {
             lableName = lableName.trim(); //清除两边空格
         }
         var c = "";
         var s = this.domList; //用已存在20210806
         if (this.domList == undefined) {
             s = this.getDocument(lableName, x, y); //查找标签对应排序如  ,1|3,6|9             
         }
         var splstr = s.split(",");
         for (var i = 1; i <= splstr.length - 1; i++) {
             var s = splstr[i];
             if (s.indexOf("|") != -1) { //双标签
                 var splxx = s.split("|");
                 this.htmlArr[splxx[0]].upHtml += value;
             } else { //单标签
                 this.htmlArr[s].upHtml += value;
             }
         }
         return this;
     }
     //获得处理完成HTML内容  不够精简20210506
     this.printHTML = function(action) {
         var c = "";
         var addLv = 0;
         for (var i = 0; i <= this.htmlArr.length - 1; i++) {
             var obj = this.htmlArr[i]
             if (obj) {
                 obj.id = i;
                 if (action == "format") { //格式化
                     var upS = obj.upHtml.trim(); //上面内容
                     var downS = obj.downHtml.trim(); //下面内容
                     var sHtml = obj.html.trim();
                     if (obj.label == "html") {
                         addLv = -1;
                     } else if (obj.label == "head" || obj.label == "body") {
                         upS += "\n";
                     }

                     if (sHtml != "") {

                         var isBR = true;
                         if (obj.tagpair == 2) {
                             if (obj.label.substr(0, 1) == "/") { //结束标签要判断与开始标签之间需不需要换行
                                 isBR = this.upCheckThisLabel(obj);
                             }
                         } else { //单标签
                             if ('|br|hr|rect|line|col|'.indexOf('|' + obj.label + '|') != -1) {
                                 isBR = false;
                             }
                         }

                         if (isBR) {
                             sHtml = "\n" + this.common.copyStr("    ", obj.lv - 1 + addLv) + sHtml; //减1是因为开始就是为一 addLv为排序htl标签块
                         }
                     }
                     c += upS + sHtml + downS;
                 } else if (action == "zip") { //压缩
                     c += obj.upHtml.trim() + obj.html.trim() + obj.downHtml.trim();
                 } else { //正常
                     c += obj.upHtml + obj.html + obj.downHtml; //downHtml是给wrap用的20210825
                 }
             }
         }
         if (action == "format") c = c.trim(); //最后清空两边空格
         return c;
     }
     //以当前对象向上寻找标签 以判断两标签对里是否有双标签了或内容里有否换行，以判断最后结束标签是否要换行 20210830
     //默认为不换行
     this.upCheckThisLabel = function(thisObj) {
         if (thisObj.label == "/head" || thisObj.label == "/body") return true; //这两个结束标签要换行
         for (var i = thisObj.id - 1; i >= 0; i--) {
             // console.log("显示"+i)
             var obj = this.htmlArr[i];
             if (obj) {
                 if (obj.lv == thisObj.lv) {
                     return false;
                 } else if (obj.tagpair == 2 || obj.label == "img") {
                     return true;
                 } else if ((obj.upHtml + obj.downHtml).indexOf("\n") != -1) { //上边和下边内容里如果有换行则需要换行20210905
                     return true;
                 }
             }
         }
         return false;
     }

     //测试
     this.debug = function(isIE) {
         if (isIE == undefined) isIE = false;
         if (isIE) {
             xiyueta.log(this.htmlArr); //在浏览器里显示
         } else {
             console.log(this.htmlArr); //在浏览器调试面板里显示
         }
     }
     //信息
     this.info = function() {
         console.log("%c xiyueta%c v" + _xyt.config.version + " website: www.xiyueta.com ", 'font-size:22px;color:#00bbee', 'color:#000');
     }
 }
 //end _XIYUETA


 var _xyt = new _XIYUETA();
 _xyt.info();

 var xiyueta = function(config, x, y) {
     return new xiyueta.fn.init(config, x, y);
 };
 xiyueta.fn = xiyueta.prototype = {
     length: 1, //长量
     selector: "", //选择器
     domList: undefined, //找到标签列表
     x: null,
     y: null
 };
 xiyueta.extend = xiyueta.fn.extend = function() {
     var options, name, src, copy, copyIsArray, clone,
         target = arguments[0] || {},
         i = 1,
         length = arguments.length

     if (i === length) {
         target = this;
         i--;
     }

     for (; i < length; i++) {
         if ((options = arguments[i]) != null) {
             for (name in options) {
                 copy = options[name];
                 if (name === "__proto__" || target === copy) {
                     continue;
                 }

                 if (copy !== undefined) {
                     target[name] = copy;
                 }
             }
         }
     }
     return target;
 };
 var init = xiyueta.fn.init = function(selector, x, y) {
     this.length = 0; //找到条数
     this.selector = selector; //选择器
     this.domList = undefined;
     this.x = x;
     this.y = y;
     if (_xyt.htmlArr.length > 0) {
         if (typeof(selector) == "string") { //选择器为字符则搜索
             var s = _xyt.getDocument(selector, x, y); //查找标签对应排序如  ,1|3,6|9              
             var splstr = s.split(",");
             this.length = splstr.length - 1;
             this.domList = s;
         } else if (typeof(selector) == "#object") { //处理对象类型20210827 如  $().each(function(i,obj){})
             this.domList = "," + selector.x
             if (selector.x != selector.y) {
                 this.domList += "|" + selector.y;
             }
             this.selector = ""; //清空
         }
     }
     _xyt.domList = this.domList; //赋值 查找到的元素集合，给字链使用
     if (this.selector == undefined) this.selector = ""; //为空
 };
 init.prototype = xiyueta.fn;
 $ = $xyt = xiyueta;

 //打印到浏览器上面 20210827 用法 $.log("info") 
 xiyueta.log = function(s, br) {
     if (br == undefined) br = "<br>";
     if (typeof(s) == "object") {
         for (var item in s) {
             var sItem = s[item] + "";
             if (sItem.indexOf("function") == -1) {
                 var sX = s[item] + ""
                 sX = sX.replace(/</g, '&lt;').replace(/\n/g, '<br>').replace(/ /g, '&nbsp;');

                 if (typeof(s[item]) == "object") {
                     sX = xiyueta.log(s[item], " , ");
                 }
                 if (typeof(sX) == "undefined") {
                     document.write(item + br);
                 } else {
                     document.write(item + ":  " + sX + br);
                 }

             }
         }
     } else {
         s += ""; //如果为数字类型，则转成字符类型
         document.write(s.replace(/</g, '&lt;').replace(/\n/g, '<br>').replace(/ /g, '&nbsp;') + br);
     }
 };

 xiyueta.fn.extend({
     parse: function(html, isRepair) { //解析HTML标签  isRepair为是否修复HTML默认为true 20210909
         _xyt.parseHTML(html);
         if (isRepair == undefined && _xyt.lv != 0) isRepair = true; //为undefined则为true并判断 lv不为0
         if (isRepair == true) {
             var obj = this.repair(false);
             if (obj.err > 0 && obj.errList != '' && obj.state == true) { //HTML有错误并且修复成功
                 _xyt.parseHTML(this.print()); //更新
             }
         }
         if (_xyt.htmlArr.length > 0) { //解析完直接处理选择器20210819
             if (typeof(this.selector) == "string") { //选择器为字符则搜索
                 var s = _xyt.getDocument(this.selector, this.x, this.y); //查找标签对应排序如  ,1|3,6|9              
                 var splstr = s.split(",");
                 this.length = splstr.length - 1;
                 this.domList = s;
                 _xyt.domList = this.domList; //赋值 查找到的元素集合 更新下
             }
         }
         return this
     },
     find: function(findConfig) { //获取当前匹配元素集合中每个元素的后代==jQuery  可再改进成 each循环这种方法20210822
         if (typeof(this.selector) == "string" && this.selector != "") {
             var splstr = this.selector.split(",");
             var c = "";
             for (var i = 0; i <= splstr.length - 1; i++) {
                 if (c != "") c += ",";
                 c += splstr[i] + " " + findConfig;
             }
             this.selector = c;

             var s = _xyt.getDocument(this.selector, this.x, this.y); //查找标签对应排序如  ,1|3,6|9              
             var splstr = s.split(",");

             this.length = splstr.length - 1;
             this.domList = s;
             _xyt.domList = this.domList; //赋值 查找到的元素集合 更新下，和inti里一样20210815
         } else if (typeof(this.selector) == "object") {
             this.x = this.selector.x + 1;
             this.y = this.selector.y - 1;
             this.selector = findConfig;
         }

         return this;
     },
     text: function(value) { //获取匹配元素集合中每个元素的组合文本内容，包括它们的后代==jQuery
         if (value != undefined) { //设置
             value = value.replace(/</g, '&lt;').replace(/>/g, '&gt;'); //转义字符
             _xyt.setHtml(this.selector, this.x, this.y, value);
             return this
         } else {
             return _xyt.getText(this.selector, this.x, this.y);
         }
     },
     html: function(value, action) { //获取匹配元素集中第一个元素的 HTML 内容==jQuery
         if (value != undefined) { //设置
             _xyt.setHtml(this.selector, this.x, this.y, value, action);
             return this;
         } else {
             return _xyt.getHtml(this.selector, this.x, this.y, action);
         }
     },
     attr: function(paramName, setValue) { //获取匹配元素集中第一个元素的属性值==jQuery
         if (setValue == undefined && typeof paramName != "object") { //获取
             return _xyt.attr(this.selector, this.x, this.y, paramName);
         } else {
             _xyt.attr(this.selector, this.x, this.y, paramName, setValue);
             return this;
         }
     },
     val: function(setValue) { //方法主要用于获取input,select和等表单元素的值textarea==jQuery
         if (setValue == undefined) {
             return _xyt.val(this.selector, this.x, this.y);
         } else {
             _xyt.val(this.selector, this.x, this.y, setValue);
             return this;
         }
     },
     remove: function() { //从 DOM 中删除匹配的元素集==jQuery
         _xyt.remove(this.selector, this.x, this.y); //删除标签对
         return this;
     },
     each: function(callback) { //为每个匹配的元素执行一个函数==jQuery
         return _xyt.each(this.selector, this.x, this.y, callback);
     },
     css: function(paramName, setValue) { //为每个匹配元素设置一个或多个 CSS 属性==jQuery
         if (setValue == undefined && typeof paramName != "object") { //获取
             return _xyt.css(this.selector, this.x, this.y, paramName);
         } else { //设置
             _xyt.css(this.selector, this.x, this.y, paramName, setValue);
             return this;
         }
     },
     print: function(action) { //打印HTML对象全部内容
         return _xyt.printHTML(action)
     },
     debug: function(isIE) { //调试        
         _xyt.debug(isIE)
         return this
     }
 });


 //外部追加
 xiyueta.fn.extend({
     eq: function(index) { //减少到指定索引
         var splstr = this.domList.split(",");
         if (index >= 0) {
             index++; //真能添加一
         } else {
             index = splstr.length + index;
         }
         var s = splstr[index];
         this.length = 1;
         this.selector = "";
         if (s != "") {
             s = ',' + s;
             this.length = 1;
         }
         _xyt.domList = this.domList = s;
         return this;
     },
     first: function() { //减少到第一条索引
         this.eq(0);
         return this;
     },
     last: function() { //减少到最后一条索引
         this.eq(-1);
         return this;
     },
     addClass: function(value) { //添加class类
         _xyt.addClass(this.selector, this.x, this.y, value);
         return this;
     },
     removeClass: function(value) { //移除class类
         _xyt.removeClass(this.selector, this.x, this.y, value);
         return this;
     },
     wrap: function(html) { //加入 repairHTML 先修复HTML 再处理20210907
         var newXYT = new _XIYUETA();
         var deepestLV = 0; //最深层级
         newXYT.parseHTML(html);
         newXYT.repairHTML(false); //修复HTML
         var c = newXYT.printHTML();
         // alert(html)
         if (html != c) {
             newXYT.parseHTML(c); //更新HTML
         }
         // newXYT.debug()

         for (var i = 0; i <= newXYT.htmlArr.length - 1; i++) {
             var obj = newXYT.htmlArr[i];
             if (obj.lv > deepestLV && obj.tagpair == 2) deepestLV = obj.lv; //为双标签，判断当前等级大于设定的
         }
         var sHead = "";
         var sFoot = "";
         var isEndLabel = false; //是否为累加结束标签
         for (var i = 0; i <= newXYT.htmlArr.length - 1; i++) {
             var obj = newXYT.htmlArr[i];
             var upHtml = obj.upHtml;
             if (obj.label.substr(0, 1) == "/" && obj.lv == deepestLV) {
                 isEndLabel = true;
                 sHead += upHtml;
                 upHtml = "";
             }
             if (isEndLabel == false) {
                 sHead += upHtml + obj.html;
             } else {
                 sFoot += upHtml + obj.html;
             }

         }
         _xyt.wrap(this.selector, this.x, this.y, sHead, sFoot);
         return this;
     },
     unwrap: function() { //从 DOM 中移除匹配元素集的父元素，将匹配元素留在原处
         _xyt.unwrap(this.selector, this.x, this.y);
         return this;
     },
     append: function(value) { //在被选元素的结尾插入内容
         _xyt.append(this.selector, this.x, this.y, value);
         return this;
     },
     prepend: function(value) { //在被选元素的开头插入内容
         _xyt.prepend(this.selector, this.x, this.y, value);
         return this;
     },
     after: function(value) { //在被选元素之后插入内容
         _xyt.after(this.selector, this.x, this.y, value);
         return this;
     },
     before: function(value) { //在被选元素之前插入内容
         _xyt.before(this.selector, this.x, this.y, value);
         return this;
     },
     htmlwrap: function(value) { //获得HTML包括外面父标签块20210804
         if (value != undefined) { //设置
             _xyt.setHtml(this.selector, this.x, this.y, value, "all");
             return this;
         } else {
             return _xyt.getHtml(this.selector, this.x, this.y, "all");
         }
     },
     dom: function(action) { //获得document结,x,y构
         return _xyt.getHtml(this.selector, this.x, this.y, "doc|" + action);
     },
     domwrap: function() { //获得document结,x,y构 包括当前元素
         return _xyt.getHtml(this.selector, this.x, this.y, "doc|all");
     },
     domlabel: function(action) { //获得document标签,x,y构
         return _xyt.getHtml(this.selector, this.x, this.y, "doc|label|" + action);
     },
     domlabelwrap: function() { //获得document标签,x,y构 包括当前元素
         return _xyt.getHtml(this.selector, this.x, this.y, "doc|all|label");
     },
     lv: function() { //获得document标签最后位置的层级数20210818
         return _xyt.lv;
     }

 })