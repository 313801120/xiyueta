﻿/*处理标签完整*/


//截取标签块20210503
_XIYUETA.prototype.cutLabel = function(lableName, action) {
    var cCss = "";
    for (var i = 0; i <= this.htmlArr.length - 1; i++) {
        var obj = this.htmlArr[i]; //标签对象
        if (obj != undefined) {
            if (obj.label == "/style") {
                cCss += obj.upHtml;
            } else if (obj.label == "link" && obj.rel == "stylesheet") {
                cCss += obj.content;
            }
        }
    }
    var cLable = "*,body,"; //标签内容
    var subA = "",
        subB = "",
        subC = "",
        subD = "" //一级到四级
    var startLocation = -1; //开始位置
    var s = this.getDocument(lableName); //获得当前dot位置    
    if (s != "") {
        s = s.replace(/,/, '');
        var x = s;
        var y = s;
        if (s.indexOf('|') != -1) { //双标记
            var splxx = s.split("|");
            x = splxx[0];
            y = splxx[1];
        }

        for (var i = x; i <= parseInt(y) - 1; i++) {
            var obj = this.htmlArr[i];
            if (obj != undefined) {
                if (obj.label.substr(0, 1) != '/') {
                    if (startLocation == -1) { //开始
                        subA = obj.label; //一级标签名
                        startLocation = obj.lv; //开始层级数
                    }
                    if (startLocation + 1 == obj.lv) subB = obj.label; //二级标签名
                    if (startLocation + 2 == obj.lv) subC = obj.label; //三级标签名
                    if (startLocation + 3 == obj.lv) subD = obj.label; //四级标签名


                    //标签+ID+Class
                    cLable += obj.label + ","
                    //标签类和ID
                    var cssId = this.handleLabelParam(obj, "id");
                    if (cssId != undefined) cLable += '#' + cssId.toLowerCase() + ","
                    var cssClass = this.handleLabelParam(obj, "class");
                    if (cssClass != undefined) cLable += '.' + cssClass.toLowerCase().replace(/ /g, ",.") + ","

                }
            }
        }
        var splxx = cLable.split(",");
        cLable = "";
        for (var i = 0; i <= splxx.length - 1; i++) {
            if (("," + cLable + ",").indexOf("," + splxx[i] + ",") == -1) {
                if (cLable != "") cLable += ",";
                cLable += splxx[i];
            }
        }

        //console.log(cLable)
        //splxx=cLable.split(",");

        var findStyle = "";
        var xytcss = new _XIYUETACSS();
        xytcss.cssParse(cCss); //解析CSS 
        for (var i = 0; i <= xytcss.cssArr.length - 1; i++) {
            var obj = xytcss.cssArr[i];
            if (obj != undefined) {
                var s = "," + obj.label + ","
                var s2 = "," + obj.label + " "
                for (var j = 0; j <= splxx.length - 1; j++) {
                    if (s.indexOf("," + splxx[j] + ",") != -1 || s.indexOf("," + splxx[j] + " ") != -1) {
                        if (('\n' + findStyle + '\n').indexOf('\n' + obj.html + '\n') == -1) {
                            findStyle += obj.html + "\n";
                        }
                    }
                }
            }

        }
        // console.log("findStyle="+findStyle)
        // console.log("打开CSS结构")
        // xytcss.debug()


        xiyuetaCSS().parse(findStyle);
        findStyle = xiyuetaCSS().print("zip"); //获得压缩后CSS



        if (findStyle != "") findStyle = "<style>" + findStyle + "\n</style>\n"; //找到的CSS样式合在一起

        var html = xiyueta(lableName).html(null, "all");
        this.parseHTML(html); //解析html
        var c = findStyle + this.printHTML("format"); //加个all带表加当前双标签标签
    }
    return c;
}

//获得网址对应的内容并且赋值到这个对象的content里20210503
// _XIYUETA.prototype.getUrlStr = function(obj, url) {
//     var _This = this;
//     $.ajax({
//         url: this.config.serverurl + '?act=getUrlStr&n=' + Math.random(),
//         type: 'POST',
//         data: {
//             'httpurl': url
//         },
//         error: function(XMLHttpRequest, textStatus, errorThrown) {
//             //alert(XMLHttpRequest)
//             //alert(textStatus)
//             //alert(errorThrown)
//         },
//         success: function(result) {
//             //处理CSS文件里内容的图片完整，好下载处理20210507
//             xiyuetaCSS().parse(result);
//             xiyuetaCSS().allcss("|url", "server=" + url); //    全部css都让有url的链接完整 
//             obj.content = xiyuetaCSS().print();
//             _This.config.downcss--;
//             if (_This.config.downcss == 0) {
//                 alert("下载全部CSS完成，可以点击下一步 了");
//             } else {
//                 alert("下载CSS完成,还乘" + _This.config.downcss);
//             }
//         }
//     });
// }



//外部追加
xiyueta.fn.extend({    
    cutlabel: function(action) { //提取标签块，包括CSS块
        return _xyt.cutLabel(this.selector, action);
    }

})