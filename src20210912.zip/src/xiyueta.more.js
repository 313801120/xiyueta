//Html标签互换 20210502
_XIYUETA.prototype.swap = function(lableName, toLabelName) {
    if (lableName == undefined || toLabelName == undefined) return false; //要互换两个有一个没有设置时 为假退出
    var s = this.getDocument(lableName); //查找标签对应排序如  ,1|3,6|9    
    var toS = this.getDocument(toLabelName); //查找标签对应排序如  ,1|3,6|9    
    // alert(s+"\n"+toS)
    if (s == "" || toS == "") return false; //两个要互换有一个不存在，则为假退出

    var splstr = s.split(",");
    var s = splstr[1];
    if (s.indexOf('|') == -1) { //单标签
        var objA = this.htmlArr[s];
    } else {
        var splxx = s.split("|");
        var objA = this.htmlArr[splxx[0]];
        var c = "";
        for (var j = parseInt(splxx[0]) + 1; j <= splxx[1]; j++) {
            var obj = this.htmlArr[j];
            if (obj != undefined) {
                c += obj.upHtml + obj.html;
                delete this.htmlArr[j]; //删除数组
            }
        }
        objA.html += c;
    }


    var splstr = toS.split(",");
    var toS = splstr[1];
    if (toS.indexOf('|') == -1) { //单标签
        var objB = this.htmlArr[toS];
    } else {
        var splxx = toS.split("|");
        var objB = this.htmlArr[splxx[0]];
        var c = "";
        for (var j = parseInt(splxx[0]) + 1; j <= splxx[1]; j++) {
            var obj = this.htmlArr[j];
            if (obj != undefined) {
                c += obj.upHtml + obj.html;
                delete this.htmlArr[j]; //删除数组
            }
        }
        objB.html += c;
    }
    var ahtml = objA.html;
    // var aupHtml = objA.upHtml;

    objA.html = objB.html;
    objB.html = ahtml;
    // objA.upHtml = objB.upHtml;
    // objB.upHtml = aupHtml;
    return true;
}
//获得项目输出数组 最后优化20210501
_XIYUETA.prototype.getItem = function(lableName, x, y, paramName) { //标签，参数名称  找到配置参数名对应的码数值
    if (paramName == undefined) paramName = ""; //参数名无效则为空
    var arrList = [];
    var s = this.getDocument(lableName, x, y); //查找标签对应排序如  ,1|3,6|9       
    var splstr = s.split(",");
    for (var i = 1; i <= splstr.length - 1; i++) {
        var s = splstr[i];
        if (s.indexOf("|") != -1) { //双标签
            var splxx = s.split("|");
            var obj = this.htmlArr[splxx[0]];
            if (paramName != "") { //参数名不为空 获得双标签里参数值
                var s = this.handleLabelParam(obj, paramName);
                if (s !== undefined) arrList.push(s);
            } else { //参数名为空则获得全部内容
                var c = obj.html; //开始标签内容
                for (var j = parseInt(splxx[0]) + 1; j <= splxx[1]; j++) { //循环除开始与结束
                    var obj = this.htmlArr[j];
                    if (obj != undefined) c += obj.upHtml + obj.html; //判断加于20210516
                }
                if (c != "") arrList.push(c); //双标签内容
            }


        } else { //为单标签
            var obj = this.htmlArr[s];
            if (paramName != "") {
                var s = this.handleLabelParam(obj, paramName)
                if (s !== undefined) arrList.push(s); //获得配置的参数值 
            } else {
                arrList.push(obj.html); //获得单标签块
            }
        }
    }
    return arrList;
}


//设置配置20210501
_XIYUETA.prototype.setConfig = function(configArr) {
    if (configArr == undefined) return this.config; //返回 读配置数组

    if (configArr.httpurl != undefined) { //仿站网址
        this.config.httpurl = configArr.httpurl;
    }
    if (configArr.serverurl != undefined) { //服务器网址
        this.config.serverurl = configArr.serverurl;
    }
    if (configArr.jsdir != undefined) { //Javascript文件目录
        this.config.jsdir = configArr.jsdir;
    }
    if (configArr.cssdir != undefined) { //CSS文件目录
        this.config.cssdir = configArr.cssdir;
    }
    if (configArr.imagesdir != undefined) { //Images图片目录
        this.config.imagesdir = configArr.imagesdir;
    }
}
//获得或设置网页编码
_XIYUETA.prototype.charset = function(value) {
    for (var i = 0; i <= this.htmlArr.length - 1; i++) {
        var obj = this.htmlArr[i]; //标签对象
        if (obj != undefined) {
            if (obj.label == "meta") {
                var s = obj.html.toLowerCase();
                if (s.indexOf("charset=") != -1) {
                    var paramValue = this.handleLabelParam(obj, "charset");
                    if (paramValue != undefined) paramValue = paramValue.toLowerCase().trim(); //转小写清空两边
                    if (paramValue == undefined) { //为空则用第二种方法
                        var paramValue = this.handleLabelParam(obj, "content");
                        if (paramValue != undefined) paramValue = paramValue.toLowerCase().trim(); //转小写清空两边                        
                        if (paramValue.indexOf("utf-8") != -1) {
                            if (value != undefined) {
                                this.handleLabelParam(obj, "content", "text/html; charset=" + value);
                                return "";
                            }
                            return "utf-8";
                        } else if (paramValue.indexOf("gb2312") != -1) {
                            if (value != undefined) {
                                this.handleLabelParam(obj, "content", "text/html; charset=" + value);
                                return "";
                            }
                            return "gb2312";
                        }
                    } else {
                        if (value != undefined) {
                            this.handleLabelParam(obj, "charset", value);
                        }
                        return paramValue; //返回找到的网页编码
                    }
                }
            }
        }
    }
}

//处理标签里参数 主要是处理图片的 修改于20210708 
_XIYUETA.prototype.getHandleSrc = function(labelList, paramName, action, httpurl) {
    var c = "";
    var s, tempS, rel;
    var isWeb = true; //是否为网页需要的网址

    for (var i = 0; i <= this.htmlArr.length - 1; i++) {
        var obj = this.htmlArr[i]; //标签对象
        if (obj != undefined) {
            if (('|' + labelList + '|').indexOf('|' + obj.label + '|') != -1) {; //标签在查找标签列表里
                var s = this.handleLabelParam(obj, paramName); //提取参数名称对应的参数值  如  src  得 1.jpg
                if (s == undefined) s = "";
                if (obj.label == "link") {
                    rel = this.handleLabelParam(obj, "rel");
                    if (rel == undefined) rel = "";
                    rel = rel.trim().toLowerCase();
                    if (rel == "dns-prefetch" || rel == "alternate") s = ""; //设置dns地址 不处理这处，为空
                }
                if (('|' + action + '|').indexOf('clean') != -1) {
                    isWeb = true; //是否为仿站，处理目录到模板  图片到images目录  javascript到js目录  css样式到css目录

                    if (s != "" && s.indexOf("apps.bdimg.com/") == -1) { //s不等空 并且排除指定网址
                        s = this.common.fullHttpUrl(httpurl, s); //处理干净完整网址         
                        tempS = s; //暂存这个干净网址

                        if (('|' + action + '|').indexOf('web') != -1) { //为需要处理成模板网站
                            s = this.common.getUrlFileName(s, obj.label); //获得URL文件名称 加动作处理，获得干净文件名称 img标签对应jpg图片类型 js标签对应js文件类型 css标签对应css文件类型

                            if (s != "") { //不为空则加相应目录
                                if (obj.label == "img") {
                                    s = this.config.imagesdir + s; //图片地址
                                } else if (obj.label == "script") { //JS目录
                                    s = this.config.jsdir + s; //js地址
                                } else if (obj.label == "link") {
                                    var rel = this.handleLabelParam(obj, "rel");
                                    if (rel == undefined) rel = "";
                                    rel = rel.trim().toLowerCase(); //判断是css文件还是ico图标
                                    if (rel.indexOf("shortcut icon") != -1) {
                                        s = this.config.imagesdir + s; //图片地址
                                    } else if (rel.indexOf("stylesheet") != -1) { //取CSS                                        
                                        s = this.config.cssdir + s; //css样式地址
                                    } else { //没有则为空
                                        s = "";
                                        isWeb = false;
                                    }
                                } else {
                                    isWeb = false;
                                    s = "";
                                }
                            }
                        }
                        if (isWeb && s != "") { //网站为真，并且文件不为空
                            if (('|' + action + '|').indexOf('down') != -1) { //down为需要下载文件列表
                                if (c != "") c += "[,]";
                                c += tempS + "[|]" + s;
                            } else {
                                if (c != "") c += "[,]";
                                c += s; //干净网址
                            }
                        }
                        this.handleLabelParam(obj, paramName, s); //替换 
                    }
                } else if (s != "") { //查找到的值不为空
                    if (c != "") c += "[,]";
                    c += s; //没有动作则显示查找到的标签 
                }
            }
        }
    }
    return c;
}

//替换标签里参数值，先判断获得这个参数值比较，再赋值 20210511
_XIYUETA.prototype.replace = function(lableName, paramName, findValue, replaceValue) { //标签，参数名称  找到配置参数名对应的码数值
    var s = this.getDocument(lableName); //查找标签对应排序如  ,1|3,6|9       
    var splstr = s.split(",");
    for (var i = 1; i <= splstr.length - 1; i++) {
        var s = splstr[i];
        if (s.indexOf("|") != -1) { //双标签
            var splxx = s.split("|");
            var obj = this.htmlArr[splxx[0]];
            if (paramName != "") { //参数名不为空 获得双标签里参数值
                var s = this.handleLabelParam(obj, paramName); //查找
                if (s == findValue) this.handleLabelParam(obj, paramName, replaceValue); //替换                     
            }


        } else { //为单标签
            var obj = this.htmlArr[s];
            if (paramName != "") {
                var s = this.handleLabelParam(obj, paramName)
                if (s == findValue) this.handleLabelParam(obj, paramName, replaceValue); //替换    
            }
        }
    }

}

//HTML修复
_XIYUETA.prototype.repairHTML = function(isTip) { //isTip=是否显示提示，默认为真
    if (isTip == undefined) isTip = false; //不直接在参数里写成 isTip=false 是为了程序能在ASP里能运行
    var obj, lvObj, nameObj;
    var repairCount = 0; //修复总数 
    var isTrue = false; //是否为真
    var sTip = ""; //提示字符串
    var nErr = 0; //错误数   如果等于层级数this.lv 会不精准，如:<div></span> 层级一致，但标签名错误
    var errList = ","; //错误标签列表 
    var isUpdateHTML = false; //是否更新HTML

    //判断防重复修复
    if (this.htmlArr.length >= 1) {
        obj = this.htmlArr[0]; //标签对象
        if (obj.isFindDom == "no") return false; //已经被修复过了，不要再重复修复会报错的2021910
    }

    //获得双标签缺少或多余标签块并加上索引  如 ,p,p,/p,/span,
    for (var i = 0; i <= this.htmlArr.length - 1; i++) {
        obj = this.htmlArr[i]; //标签对象
        if (obj) {
            obj.nIndex = i;
            if (obj.tagpair == 2) { //双标签
                if (obj.label.substr(0, 1) == '/') { //结束标签，判断
                    var labelName = obj.label.substr(1); //结束标签名不带/
                    if ((',' + errList + ',').indexOf(',' + labelName + ',') != -1) { //判断是否有开始标签
                        errList = errList.replace(',' + labelName + ',', ','); //去掉一个标签
                    } else {
                        errList += obj.label + ","; //追加结束标签
                    }
                } else {
                    errList += obj.label + ","; //追加开始标签
                }
            }
        }
    }


    //处理网页双标签是否有错误 并修复
    for (var i = 0; i <= this.htmlArr.length - 1; i++) {
        obj = this.htmlArr[i]; //标签对象
        if (obj) {
            if (obj.tagpair == 2) { //双标签
                if (obj.label.substr(0, 1) == '/') { //结束标签判断
                    var labelName = obj.label.substr(1); //结束标签名不带/
                    lvObj = this.upFindSameLvObj(i, obj); //向上找同等级对象
                    isTrue = true;
                    //找LV层级
                    if (lvObj != null) { //结束标签向上找到开始标签 如/div  div
                        if (obj.label == ("/" + lvObj.label)) { //结束标签与开始正确匹配 如 </div> <div>
                            isTrue = false;
                            this.setNoFindDom(lvObj.nIndex, obj.nIndex); //设置为不搜索标签块
                            if (isTip) console.log("找(Lv1)", { label: obj.label, lvtolv: lvObj.nIndex + "-" + obj.nIndex })

                            //整体层级正确，并且当前当前与搜索对象都为第一层
                        } else if (this.lv == 0 || (lvObj.lv == 1 && obj.lv == 1)) {
                            if (isTrue == true) {
                                sTip = "";
                                if (isTip) sTip = "<" + "!--xiyueta提示: 原标签(LV) " + obj.label + " 替换成 /" + lvObj.label + "-->"; //字符分开是为了兼容ASP20210824
                                obj.html = "</" + lvObj.label + ">" + sTip;
                                repairCount += 2; //修复记录数累加 +2是因为它是两个标签
                                nErr += 2; //错误标签数累加 +2是因为它是两个标签
                                isTrue = false;
                                this.setNoFindDom(lvObj.nIndex, obj.nIndex); //设置为不搜索标签块
                                if (isTip) console.log("找(Lv2) LV整体层级正确或两标签都为第一层  " + obj.label + " 替换成 /" + lvObj.label)

                            }
                        } else {
                            if (isTip) console.log("找(Lv else) 没找到，交给下面找同名", { label: obj.label })
                        }
                    }

                    //找name名称
                    if (isTrue == true) {
                        nameObj = this.upFindSameNameObj(i, obj); //标签名对应的开始标签位置
                        if (nameObj == null) { //向上没有找到同名标签，则为多余
                            obj.html = isTip ? "<" + "!---xiyueta提示: 有多余结束标签 " + obj.label + " -->" : "";
                            nErr++;
                            repairCount++; //修复记录数累加
                            this.setNoFindDom(obj.nIndex, obj.nIndex); //设置为不搜索标签块
                            this.reairHtmlLv(obj, 1); //修复HTML数组里层级
                            if (isTip) console.log("找(Name 出错)" + " 有多余结束标签 " + obj.label)
                            isTrue = false;
                        } else {
                            sTip = "";
                            if (isTip) { //判断
                                nameObj.html += "<" + "!---xiyueta提示: 有问题标签开始位置-->"
                                obj.html = "<" + "!---xiyueta提示: 有问题标签结束位置-->" + obj.html;
                                console.log("找(Name2 有问题) " + obj.label + " 与 " + nameObj.label + " 之间有问题");
                            }

                            var sAddToUpHtml = "";
                            this.setNoFindDom(nameObj.nIndex, obj.nIndex); //设置为不搜索标签块
                            var addLv = nameObj.lv - obj.lv;
                            this.reairHtmlLv(obj, addLv); //修复HTML数组里层级
                            //搜索有问题标签对之间
                            for (var j = nameObj.nIndex + 1; j <= obj.nIndex; j++) {
                                var newObj = this.htmlArr[j];
                                if (newObj.label.substr(0, 1) != "/" && newObj.tagpair == 2) {
                                    var isFind = false;
                                    for (p = newObj.nIndex + 1; p <= obj.nIndex; p++) {
                                        var objB = this.htmlArr[p];
                                        if (objB.tagpair == 2 && objB.label.substr(0, 1) == "/" && objB.lv == newObj.lv) { //双标签
                                            isFind = true;
                                            break;
                                        }
                                    }
                                    if (isFind == false) {
                                        sAddToUpHtml += "</" + newObj.label + ">"
                                        if (isTip) {
                                            sAddToUpHtml += "<" + "!--xiyueta提示: 追加 /" + newObj.label + " -->";
                                            console.log("找(Name3) " + " 追加结束标签 /" + newObj.label);
                                        }
                                        nErr++; //错误数累加
                                        repairCount++; //修复完成累加
                                    }
                                }
                            }
                            obj.upHtml += sAddToUpHtml;
                        }
                    }
                }
            }

        }
    }

    //修复最后省下的错误标签列表
    var splxx = errList.split(",");
    if (splxx.length > repairCount) { //最后补齐剩下没有结束标签对
        var sAddToUpHtml = "";
        for (i = nErr + 1; i <= splxx.length - 1; i++) {
            if (splxx[i] != "") {
                // console.log(i, nErr, repairCount, splxx.length, splxx[i]);
                var sTip = "";
                if (isTip) sTip = "<" + "!--xiyueta提示: 追加 /" + splxx[i] + " -->";
                sAddToUpHtml = "</" + splxx[i] + ">" + sTip + sAddToUpHtml;
                nErr++; //错误累加
                repairCount++; //修复数累加
            }
        }
        this.htmlArr[this.htmlArr.length - 1].downHtml += sAddToUpHtml;
    }


    var state = nErr == repairCount ? true : false; //错误和修复数相等状态为真
    if (errList == ",") errList = ""; //错误列表清空
    return { lv: this.lv, err: nErr, repair: repairCount, state: state, errList: errList }
}

//设置为不处理标签块20210829
_XIYUETA.prototype.setNoFindDom = function(x, y) {
    // alert(x + "/" + y)
    for (var j = x; j <= y; j++) {
        var obj = this.htmlArr[j]; //标签对象
        if (obj) {
            obj.isFindDom = "no"; //为no则不搜索

        }
    }
    return null;
}
//找HTML某个结束标签的开始标签位置
_XIYUETA.prototype.upFindSameLvObj = function(i, focusObj) {
    // console.log(focusObj, nNoFindX, nNoFindY)
    for (var j = i - 1; j >= 0; j--) {
        var obj = this.htmlArr[j]; //标签对象
        if (obj) {
            if (obj.isFindDom != "no") {
                if (focusObj.lv == obj.lv) {
                    return obj;
                }
            }
        }
    }
    return null;
}
//找HTML某个结束标签的开始标签名称位置
_XIYUETA.prototype.upFindSameNameObj = function(i, focusObj) {
    for (var j = i - 1; j >= 0; j--) {
        var obj = this.htmlArr[j]; //标签对象
        if (obj) {
            if (obj.isFindDom != "no") {
                if (focusObj.label == "/" + obj.label) {
                    return obj;
                }
            }
        }
    }
    return null;
}
//修复HTML数组里层级 以当前对象为开始位置，往下给全部对象加减层级
_XIYUETA.prototype.reairHtmlLv = function(obj, addLv) {
    for (var i = obj.nIndex; i <= this.htmlArr.length - 1; i++) {
        obj = this.htmlArr[i]; //标签对象
        if (obj) {
            obj.lv += addLv;
        }
    }
}



//域名和网址合成一个完整网址
xiyueta.fullurl = function(httpurl, url) {
    return _xyt.common.fullHttpUrl(httpurl, url);
}
//获得网址里文件名称
xiyueta.getUrlFileName = function(httpurl, sTyle) {
    return _xyt.common.getUrlFileName(httpurl, sTyle);
}


//外部追加
xiyueta.fn.extend({
    swap: function(toLabelName) { //互换
        _xyt.swap(this.selector, toLabelName); //Html标签互换 
        return this;
    },
    item: function(paramName) {
        return _xyt.getItem(this.selector, this.x, this.y, paramName);
    },
    config: function(configArr) { //配置
        var s = _xyt.setConfig(configArr); //配置数组
        if (s == undefined) {
            return this;
        }
        return s;
    },
    charset: function(value) { //网页编码
        if (value == undefined) {
            return _xyt.charset();
        }
        _xyt.charset(value); //设置
        return this;
    },

    handle: function(paramName, action, httpurl) { //处理标签里参数 
        return _xyt.getHandleSrc(this.selector, paramName, action, httpurl);
    },
    replace: function(paramName, findValue, replaceValue) { //替换，暂时保留，仿站里用到
        return _xyt.replace(this.selector, paramName, findValue, replaceValue);
    },
    clear: function() { //清除不需要的标签，暂时不处理，给能前程序用的，保留
        return this;
    },
    repair: function(isTip) {
        return _xyt.repairHTML(isTip);
    }

})