﻿//设置配置20210501
_XIYUETA.prototype.setTplConfig = function(configArr) {
    if (configArr == undefined) return this.tplConfig; //返回 读配置数组
    if (typeof(configArr) == "object") {
        if (configArr.type != undefined) this.tplConfig.type = configArr.type; //类型
        if (configArr.item != undefined) this.tplConfig.item = configArr.item; //项多少条时处理

        if (this.tplConfig.type == "dedecms") {
            this.tplConfig.webTitle = "{dede:global.cfg_webname/}"
            this.tplConfig.webKeywords = "{dede:global.cfg_keywords/}"
            this.tplConfig.webDescription = "{dede:global.cfg_description/}"

            this.tplConfig.navFor = "{dede:channel type='top' row='10'}\n"
            this.tplConfig.navTitle = "[field:typename/]"
            this.tplConfig.navUrl = "[field:typeurl/]"
            this.tplConfig.navEnd = "{/dede:channel}"

            this.tplConfig.itemFor = "自动"
            this.tplConfig.itemTitle = "[field:title/]"
            this.tplConfig.itemUrl = "[field:arcurl/]"
            this.tplConfig.itemImage = "[field:image/]"
            this.tplConfig.itemAbout = "[field:title/]"
            this.tplConfig.itemBody = "[field:title/]"
            this.tplConfig.itemTime = '[field:pubdate function="MyDate(\'Y-m-d H:i\',@me)"/]'
            this.tplConfig.itemTime1 = '[field:pubdate function="MyDate(\'Y-m-d\',@me)"/]'
            this.tplConfig.itemEnd = "{/dede:arclist}"
        } else {
            this.tplConfig.webTitle = "<%=webTitle%>"
            this.tplConfig.webKeywords = "<%=webKeywords%>"
            this.tplConfig.webDescription = "<%=webDescription%>"

            this.tplConfig.navFor = '<%rs.open "select * from " & db_PREFIX & "WebColumn where parentId=-1 and isThrough=1 order by sortRank asc" ,conn,1,1\nwhile not rs.eof\n%>' + "\n";
            this.tplConfig.navTitle = '<%=rs("columnName")%>'
            this.tplConfig.navUrl = '<%=getNavUrl(rs("id"),rs("columnType"))%>'
            this.tplConfig.navEnd = '<%rs.movenext:wend:rs.close%>'

            this.tplConfig.itemFor = "自动"
            this.tplConfig.itemTitle = '<%=rs("title")%>'
            this.tplConfig.itemUrl = 'detail.asp?id=<%=rs("id")%>'
            this.tplConfig.itemImage = '<%=rs("smallimage")%>'
            this.tplConfig.itemAbout = '<%=rs("aboutContent")%>'
            this.tplConfig.itemBody = '<%=cutStr(rs("bodyContent"),260,"...")%>';
            this.tplConfig.itemTime = '<%=rs("addDateTime")%>'
            this.tplConfig.itemTime1 = '<%=format_Time(rs("addDateTime"),2)%>'
            this.tplConfig.itemEnd = '<%rs.movenext:next:rs.close%>'
        }
    }
}

//网页转模板网页20210515
_XIYUETA.prototype.webtpl = function(config, configArr) {
    if(config ==undefined)config = "";//兼容ASP
    this.setTplConfig(configArr); //处理配置

    xiyueta("title").html(this.tplConfig.webTitle)
    xiyueta("meta[name|NOUL=keywords]").attr("content", this.tplConfig.webKeywords)
    xiyueta("meta[name|NOUL=description]").attr("content", this.tplConfig.webDescription);

    var isFindLabel = false; //是否为开始找一级标签
    var oneLevelArr = []; //第一层对象数组
    var lv = -1;
    for (var i = 0; i <= this.htmlArr.length - 1; i++) { //循环获得一层对象列表
        var obj = this.htmlArr[i]; //标签对象
        if (obj != undefined) {
            if (obj.label == "body") {
                lv = obj.lv;
                isFindLabel = true; //找一级标签开始
            } else if (isFindLabel == false && "|div|span|table|ul|table|".indexOf('|' + obj.label + '|') != -1) {
                // this.handleLabelParam(obj, "class").trim().toLowerCase();
                // this.handleLabelParam(obj, "id").trim().toLowerCase();
                obj.x = i;
                oneLevelArr.push(obj);
                isFindLabel = true; //找标签为真了,不需要再出现body
                lv = 0;


            } else if (isFindLabel && obj.lv - lv == 1 && obj.tagpair == 2) { //找第一层，只针对双标签 要减去body
                if (obj.label.substr(0, 1) != "/" && obj.label != "!--" && obj.label.substr(0, 6) != "script") {
                    // this.handleLabelParam(obj, "class").trim().toLowerCase();
                    // this.handleLabelParam(obj, "id").trim().toLowerCase();
                    obj.x = i;
                    oneLevelArr.push(obj);
                }
            }

        }
    }
    console.log("oneLevelArr一层", oneLevelArr)
    this.tplArr = [];
    var count = oneLevelArr.length - 1;
    // count = 0
    for (var i = 0; i <= count; i++) { //循环第一层对象  然后生成模板网页
        var rootObj = oneLevelArr[i]; //第一层对象
        if (rootObj != undefined) {
            if (rootObj.id != undefined) {
                var config = rootObj.label + "[id=" + rootObj.id + "]";
            } else if (rootObj.class != undefined) {
                var config = rootObj.label + "[class='" + rootObj.class + "']";
            } else {
                var config = rootObj.label;
            }
            var x = rootObj.x;
            var y = this.getHtmlArrY(rootObj, rootObj.x); //根据当前对象和x值，获得y值            
            var n = xiyueta(config, x, y).item().length;
            // if (n == 1) { //等于1，它是独一无二的  多个一样的不处理   它不需要独一无二这一步20210527 因为它有xy定位，要不然处理不了这种<div><div></div><div></div><div></div></div>
            // alert(config+",n="+n)
            this.getSubList(x, y);
            // }
        }
    }
    console.log("this.tplArr处理", this.tplArr);

    //循环找到的模板项
    for (var i = 0; i <= this.tplArr.length - 1; i++) {
        var obj = this.tplArr[i]; 
        var x = obj.x;
        var y = obj.y;
        var labelC = obj.label;
        var nLen = labelC.lastIndexOf(" ");
        var sConfig = labelC.substr(0, nLen).trim();
        var sLabel = labelC.substr(nLen + 1).trim();
        var txt = xiyueta("*", x, y).text(); //获得文本来判断是导航，还是新闻，或是产品
          // console.log("obj",obj,sConfig,x,y,txt)
        if (txt.indexOf("首页") != -1) {
            console.log("导航 x:" + x + ",y:" + y + " " + sLabel + " " + obj.count);
            xiyueta(sConfig, x, y).nav(sLabel); //生成模板网页里的导航
        } else {
            console.log("新闻 x:" + x + ",y:" + y + " " + sLabel + " " + obj.count);
            // alert("x="+obj.x)
            // console.log("obj",obj)
            xiyueta(sConfig, x, y).news(sLabel); //生成模板网页里的导航
        }
    }

    if (this.tplConfig.type == "xiyuetacms") { //远的模板里的版权所有块20210604
        if (this.htmlSource.indexOf("版权所有") != -1) {
            alert("有版权所有")
            for (var i = 0; i <= this.htmlArr.length - 1; i++) {
                var obj = this.htmlArr[i];
                if (obj !== undefined) {
                    if (obj.upHtml.indexOf("版权所有") != -1) {
                        for (var j = i - 1; j > 0; j--) {
                            var objx = this.htmlArr[j];
                            if (objx != undefined) {
                                if (objx.tagpair == 2 && objx.label.substr(0, 1) != '/') {
                                    xiyueta(objx.label, j, i).html("<%=copyright%>"); //替换成版权所有
                                    j = 0;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

}
//获得htmlArr数组的Y值 20210518
_XIYUETA.prototype.getHtmlArrY = function(thisObj, x) {
    for (var i = x + 1; i <= this.htmlArr.length - 1; i++) { //循环获得一层对象列表
        var obj = this.htmlArr[i]; //标签对象
        if (obj.lv == thisObj.lv) {
            return i;
        }
    }
    return null

}
//找子类
_XIYUETA.prototype.getSubList = function(x, y, focusLv) { //xy为第一层的位置    
    var labelList = "";
    for (var i = x + 1; i <= y; i++) {
        var obj = this.htmlArr[i];
        if (obj != undefined) {
            if (focusLv == undefined) focusLv = obj.lv;
            if (focusLv == obj.lv) {
                if (obj.label.substr(0, 1) != '/') { //开始位置                    
                    var newY = this.getHtmlArrY(obj, i);
                    if (('|' + labelList + '|').indexOf('|' + obj.label + '|') == -1 && (obj.label.substr(0, 1) !== '<' && obj.label.substr(0, 1) !== '{')) { //排序重复  排除<程序{模板标记 
                        labelList += obj.label + "|";

                        var count = this.getLabelCount(x, y, obj.label, obj.lv);
                        if (count >= this.tplConfig.item) { //获得相同标签个数等于或大于设置的项是，则处理这个标签20210519                            
                            this.tplArr.push({
                                label: obj.label,
                                x: i,
                                y: y,
                                count: count
                            })
                        }

                    }
                    // console.log(obj.label,i,newY)
                    if (obj.tagpair == 2) this.getSubList(i, newY); //为双标签的时候，操作子类
                }
            }
        }
    }
    return ""

}
//获得指定标签内下一级指定标签的总数
_XIYUETA.prototype.getLabelCount = function(x, y, findLabel, focusLv) {
    var count = 0;
    var item;
    var id = -1;
    for (var i = x + 1; i <= y; i++) {
        var obj = this.htmlArr[i];
        if (obj != undefined) {
            if (focusLv == undefined) focusLv = obj.lv;
            if (focusLv == obj.lv && findLabel == obj.label) {
                id++;
                var newY = this.getHtmlArrY(obj, i);
                var s = xiyueta(obj.label, i, newY).dom("lable");
                if (item == undefined) {
                    item = s;
                    count++;
                } else if (item == s) {
                    count++;
                }
                // alert(item+"=="+s);
            }
            //count++;
        }
    }
    return count;
}



//生成模板导航20210514
_XIYUETA.prototype.nav = function(config, x, y, label) {
    if(config==undefined)config="";
    if (config != "") config += " "; //查找主标记不为空则加个空格
    if (label == "a" && config != "") {
        aConfig = config.trim();
    } else {
        aConfig = config + label.trim();
    }

    if (this.tplConfig.webTitle == undefined) xiyueta().tplconfig({}); //自动加载模板配置

    //不可以删除，下面要进行项比较，看那个是当前正在浏览项，要营销部开的，但是这个东西做的不是很好，等改进 a.html()20210518
    if (label == "a") {
        xiyueta(aConfig, x, y).attr("href", "#"); //清空列表下的href
        xiyueta(aConfig, x, y).attr("title", ""); //清空列表下的title
        xiyueta(aConfig, x, y).attr("alt", ""); //清空列表下的alt
        xiyueta(aConfig, x, y).html(""); //清空列表下的text内容
    } else {
        xiyueta(aConfig + " a", x, y).attr("href", "#"); //清空列表下的href
        xiyueta(aConfig + " a", x, y).attr("title", ""); //清空列表下的title
        xiyueta(aConfig + " a", x, y).attr("alt", ""); //清空列表下的alt
        xiyueta(aConfig + " a", x, y).html(""); //清空列表下的text内容
    }
    var defaultNavIndex = -1; //默认导航项索引
    var focusNavIndex = -1; //交点导航项索引
    var defaultNav = ""; //默认导航项内容
    var focusNav = ""; //交点导航项内容
    var defaultNavCount = -1; //默认导航项总数
    var focusNavCount = -1; //交点导航项总数   这个是和上面对比，看那个是交点和默认项
    var listCount = 0; //列表项决数

    xiyueta(aConfig, x, y).each(function(index, obj) {
        if (defaultNav == "") { //默认导行列表为空
            defaultNav = obj.html + obj.innerHTML;
            defaultNavCount = 1;
            defaultNavIndex = index;
        } else if (defaultNav == obj.html + obj.innerHTML) { //默认导行不为空
            defaultNavCount++; //累加
        } else { //出现交点导航情况
            if (focusNav == "") { //交点导航为空
                focusNav = obj.html + obj.innerHTML;
                focusNavCount = 1;
                focusNavIndex = index;
            } else if (focusNav == obj.html + obj.innerHTML) {
                focusNavCount++;
            } else { //重新计算交点导航
                focusNav = obj.html + obj.innerHTML;
                focusNavCount = 1;
                focusNavIndex = index;
            }
        }
        listCount++; //列表项累加
    });


    var labelType = xiyueta(aConfig + ":eq(" + defaultNavIndex + ")", x, y).dom("doc|label|");

    if (label == "a" && labelType == "") { //导航默认项为单独A标签
        xiyueta(aConfig + ":eq(" + defaultNavIndex + ")", x, y).attr("href", this.tplConfig.navUrl); //a加链接
        xiyueta(aConfig + ":eq(" + defaultNavIndex + ")", x, y).attr("title", this.tplConfig.navTitle); //a加title
        xiyueta(aConfig + ":eq(" + defaultNavIndex + ")", x, y).html(this.tplConfig.navTitle); //a内容
    } else if (labelType == "<a></a>") {
        xiyueta(aConfig + ":eq(" + defaultNavIndex + ") a", x, y).attr("href", this.tplConfig.navUrl); //a加链接
        xiyueta(aConfig + ":eq(" + defaultNavIndex + ") a", x, y).attr("title", this.tplConfig.navTitle); //a加title
        xiyueta(aConfig + ":eq(" + defaultNavIndex + ") a", x, y).html(this.tplConfig.navTitle); //a内容        
    }else{
        console.log("未找到",labelType)
    }

    if (focusNavIndex != -1) {
        if (label == "a" && labelType == "") { //导航默认项为单独A标签
            xiyueta(aConfig + ":eq(" + focusNavIndex + ")", x, y).attr("href", this.tplConfig.navUrl); //a加链接
            xiyueta(aConfig + ":eq(" + focusNavIndex + ")", x, y).attr("title", this.tplConfig.navTitle); //a加title
            xiyueta(aConfig + ":eq(" + focusNavIndex + ")", x, y).html(this.tplConfig.navTitle); //a内容
        } else if (labelType == "<a></a>") {
            xiyueta(aConfig + ":eq(" + focusNavIndex + ") a", x, y).attr("href", this.tplConfig.navUrl); //a加链接
            xiyueta(aConfig + ":eq(" + focusNavIndex + ") a", x, y).attr("title", this.tplConfig.navTitle); //a加title
            xiyueta(aConfig + ":eq(" + focusNavIndex + ") a", x, y).html(this.tplConfig.navTitle); //a内容        
        }
        var focusNav = xiyueta(aConfig + ":eq(" + focusNavIndex + ")", x, y).html(null, "all"); //获得第一条列表全部内容

        //处理导航里的定义交点  问题解决待更加完整20210604
        if (this.tplConfig.type == "xiyuetacms") {
            var sA = xiyueta(aConfig + ":eq(" + defaultNavIndex + ")", x, y).html();
            var sB = xiyueta(aConfig + ":eq(" + focusNavIndex + ")", x, y).html();
            if (sA == sB) { //比较子类里内容是否一致
                var sA = xiyueta(aConfig + ":eq(" + defaultNavIndex + ")", x, y).attr("class");
                var sB = xiyueta(aConfig + ":eq(" + focusNavIndex + ")", x, y).attr("class");
                if (sA != sB) { //比较导航项的class是否一样
                    var sFocus = sA,
                        sDefault = sB;
                    if (focusNavCount < defaultNavCount) {
                        sFocus = sB;
                        sDefault = sA;
                    }
                    xiyueta(aConfig + ":eq(" + defaultNavIndex + ")", x, y).attr("class", '<%=IIF(isFocusNav(rs),"' + sFocus + '","' + sDefault + '")%>')
                }
            }
        }

    }

    var defaultNav = xiyueta(aConfig + ":eq(" + defaultNavIndex + ")", x, y).html(null, "all"); //获得第一条列表全部内容
    // alert("aConfig="+aConfig+",defaultNav="+defaultNav+",defaultNavIndex="+defaultNavIndex);
    if (focusNavCount > defaultNavCount) {
        var sTemp = defaultNav;
        defaultNav = focusNav;
        focusNav = sTemp;
    }
    //删除多余列表项标签
    for (var i = 0; i <= listCount; i++) {
        xiyueta(config + label + ":eq(1)", x, y).remove();
    }
    //生成导航模板，这里可以选择生成那种模板样式，如dedecms aspcms phpcms等等
    var c = this.tplConfig.navFor;
    if (focusNavCount == -1) {
        c += defaultNav;
    } else {
        if (this.tplConfig.type == "dedecms") {
            if (focusNav != "") {
                focusNav = focusNav.replace(/"/g, "'").replace(/\[field:/g, "~").replace(/\/]/g, "~")
                c = c.replace("}", ' currentstyle="' + focusNav + '"}')
            }
            c += defaultNav + "\n";

        } else {
            if (defaultNav.indexOf("isFocusNav(rs)") != -1) {
                c += defaultNav;
            } else if (focusNav.indexOf("isFocusNav(rs)") != -1) {
                c += focusNav;
            } else {
                c += '<%if isFocusNav(rs) then%>\n' + focusNav + '\n<%else%>\n' + defaultNav + '\n<%end if%>\n';
            }
        }
    }

    c += this.tplConfig.navEnd;
    xiyueta(config + label + ":eq(0)", x, y).html(c, "all");
}


//生成模板导航20210514
_XIYUETA.prototype.news = function(config, x, y, label) {
    if(config==undefined)config="";
    if (config != "") config += " "; //查找主标记不为空则加个空格
    if (label == "a" && config != "") { //config也有可以为空，因为有,x,y位置定位来区分
        aConfig = config.trim();
    } else {
        aConfig = config + label.trim();
    }
    var labelType = xiyueta(aConfig + ":eq(0)", x, y).dom("doc|label|");
    if (this.tplConfig.webTitle == undefined) xiyueta().tplconfig({}); //自动加载模板配置

    if (labelType == "<a></a>") {
        xiyueta(aConfig + ":eq(0) a", x, y).attr("href", this.tplConfig.itemUrl); //a加链接
        if (xiyueta(aConfig + ":eq(0) a", x, y).attr("title") != "") xiyueta(aConfig + ":eq(0) a", x, y).attr("title", this.tplConfig.itemTitle); //a加title
        xiyueta(aConfig + ":eq(0) a", x, y).html(this.tplConfig.itemTitle); //a内容
    } else if (labelType == "<a><img><h1></h1></a>") {
        xiyueta(aConfig + ":eq(0) a", x, y).attr("href", this.tplConfig.itemUrl); //a加链接
        if (xiyueta(aConfig + ":eq(0) a", x, y).attr("title") != "") xiyueta(aConfig + ":eq(0) a", x, y).attr("title", this.tplConfig.itemTitle); //a加title
        xiyueta(aConfig + ":eq(0) img", x, y).attr("src", this.tplConfig.itemImage); //图片
        xiyueta(aConfig + ":eq(0) h1", x, y).html(this.tplConfig.itemTitle); //h2加内容
    } else if (labelType == "<a><label><img></label><h1></h1><p></p><span></span></a>") {
        xiyueta(aConfig + ":eq(0) a", x, y).attr("href", this.tplConfig.itemUrl); //a加链接
        if (xiyueta(aConfig + ":eq(0) a", x, y).attr("title") != "") xiyueta(aConfig + ":eq(0) a", x, y).attr("title", this.tplConfig.itemTitle); //a加title
        xiyueta(aConfig + ":eq(0) img", x, y).attr("src", this.tplConfig.itemImage); //图片
        xiyueta(aConfig + ":eq(0) h1", x, y).html(this.tplConfig.itemTitle); //h2加内容
        xiyueta(aConfig + ":eq(0) p", x, y).html(this.tplConfig.itemAbout); //p简要说明
    } else if (labelType == "<a><img><span></span></a>") {
        xiyueta(aConfig + ":eq(0) img", x, y).attr("src", this.tplConfig.itemImage); //图片
        xiyueta(aConfig + ":eq(0) span", x, y).html(this.tplConfig.itemTitle); //标题
        xiyueta(aConfig + ":eq(0) a", x, y).attr("href", this.tplConfig.itemUrl); //a加链接
        if (xiyueta(aConfig + ":eq(0) a", x, y).attr("title") != "") xiyueta(aConfig + ":eq(0) a", x, y).attr("title", this.tplConfig.itemTitle); //a加title


    } else if (labelType == "<a></a><span></span>") {
        xiyueta(aConfig + ":eq(0) a", x, y).attr("href", this.tplConfig.itemUrl); //a加链接
        if (xiyueta(aConfig + ":eq(0) a", x, y).attr("title") != "") xiyueta(aConfig + ":eq(0) a", x, y).attr("title", this.tplConfig.itemTitle); //a加title
        xiyueta(aConfig + ":eq(0) a", x, y).html(this.tplConfig.itemTitle); //a内容
        xiyueta(aConfig + ":eq(0) span", x, y).html(this.handleItemTime(aConfig, x, y, this.tplConfig.itemTitle)); //span 先判断是否为时间，不是就把标签给它
    } else if (labelType == "<div><a><div><img></div><div><p></p></div></a></div>") {
        xiyueta(aConfig + ":eq(0) a", x, y).attr("href", this.tplConfig.itemUrl); //a加链接
        if (xiyueta(aConfig + ":eq(0) a", x, y).attr("title") != "") xiyueta(aConfig + ":eq(0) a", x, y).attr("title", this.tplConfig.itemTitle); //a加title
        xiyueta(aConfig + ":eq(0) img", x, y).attr("src", this.tplConfig.itemImage); //图片
        if (xiyueta(aConfig + ":eq(0) img", x, y).attr("alt") != "") xiyueta(aConfig + ":eq(0) img", x, y).attr("alt", this.tplConfig.itemTitle); //a加title        
        xiyueta(aConfig + ":eq(0) p", x, y).html(this.tplConfig.itemTitle); //标题
    } else if (labelType == "<div><a><i></i><h3></h3><span><span></span></span></a></div>") {
        xiyueta(aConfig + ":eq(0) a", x, y).attr("href", this.tplConfig.itemUrl); //a加链接
        if (xiyueta(aConfig + ":eq(0) a", x, y).attr("title") != "") xiyueta(aConfig + ":eq(0) a", x, y).attr("title", this.tplConfig.itemTitle); //a加title
        xiyueta(aConfig + ":eq(0) h3", x, y).html(this.tplConfig.itemTitle); //第5个div
        xiyueta(aConfig + ":eq(0) span:eq(1)", x, y).html(this.tplConfig.itemBody); //第2个span



        var item = xiyueta(undefined, x, y).item("style")
        for (var i = 0; i <= item.length - 1; i++) {
            xiyuetaCSS().parse("aa{" + item[i] + "}"); //解析html 
            xiyuetaCSS().config({ parentdir: "" }); //css里不需要../

            var c = xiyuetaCSS().allcss("|url"); //获得全部URL
            xiyuetaCSS().allcss("|url", this.tplConfig.itemImage);

            if (c != "") {
                var s = xiyuetaCSS().print().trim();
                xiyueta().replace("style", item[i], s.substr(3, s.length - 4)); //替换  去除两边空格                
            }
        }








    } else if (labelType == "<a><img><p></p></a>") {
        xiyueta(aConfig + ":eq(0) a", x, y).attr("href", this.tplConfig.itemUrl); //a加链接
        if (xiyueta(aConfig + ":eq(0) a", x, y).attr("title") != "") xiyueta(aConfig + ":eq(0) a", x, y).attr("title", this.tplConfig.itemTitle); //a加title
        xiyueta(aConfig + ":eq(0) img", x, y).attr("src", this.tplConfig.itemImage); //图片
        if (xiyueta(aConfig + ":eq(0) img", x, y).attr("alt") != "") xiyueta(aConfig + ":eq(0) img", x, y).attr("alt", this.tplConfig.itemTitle); //a加title
        xiyueta(aConfig + ":eq(0) p", x, y).html(this.tplConfig.itemTitle); //p


    } else if (labelType == "<a><div><img></div><div><div><div></div></div></div></a>") {
        xiyueta(aConfig + ":eq(0) a", x, y).attr("href", this.tplConfig.itemUrl); //a加链接
        if (xiyueta(aConfig + ":eq(0) a", x, y).attr("title") != "") xiyueta(aConfig + ":eq(0) a", x, y).attr("title", this.tplConfig.itemTitle); //a加title
        xiyueta(aConfig + ":eq(0) img", x, y).attr("src", this.tplConfig.itemImage); //图片
        if (xiyueta(aConfig + ":eq(0) img", x, y).attr("alt") != "") xiyueta(aConfig + ":eq(0) img", x, y).attr("alt", this.tplConfig.itemTitle); //a加title
        xiyueta(aConfig + ":eq(0) div:eq(3)", x, y).html(this.tplConfig.itemTitle); //第5个div


    } else if (labelType == "") {
        xiyueta(aConfig + ":eq(0)", x, y).html(this.tplConfig.itemTitle); //等于标题
        if (label == "a") {
            xiyueta(aConfig + ":eq(0)", x, y).attr("href", this.tplConfig.itemUrl); //a加链接
            if (xiyueta(aConfig + ":eq(0) a", x, y).attr("title") != "") xiyueta(aConfig + ":eq(0) a", x, y).attr("title", this.tplConfig.itemTitle); //a加title
        }

    } else {
        console.log("labelType(标签类型项没有处理)=" + labelType)
    }



    var defaultItem = xiyueta(config + label + ":eq(0)", x, y).html(null, "all"); //第一个
    // alert("defaultItem=" + defaultItem)


    var listCount = xiyueta(config + label, x, y).item().length;
    if (listCount == 0) listCount = 10; //默认为显示10条
    // alert(config + label+"="+listCount)

    //删除多余列表项标签
    for (var i = 0; i <= listCount; i++) {
        xiyueta(config + label + ":eq(1)", x, y).remove();
    }
    //生成导航模板，这里可以选择生成那种模板样式，如dedecms aspcms phpcms等等
    if (this.tplConfig.type == "dedecms") {
        var c = "{dede:arclist titlelen='60' row='" + listCount + "'}";
    } else {
        var c = '<%rs.open "select * from " & db_PREFIX & "ArticleDetail where parentId in("& getNameToAllId("产品中心") &") order by sortRank desc" ,conn,1,1\nfor i=1 to ' + listCount + '\nif rs.eof then exit for\n%>' + "\n";
    }

    c += defaultItem;
    c += this.tplConfig.itemEnd
    xiyueta(config + label + ":eq(0)", x, y).html(c, "all")
}
//处理项里时间20210518   <span>[2021-01-03]</span>
_XIYUETA.prototype.handleItemTime = function(aConfig, x, y, s) {
    var span = xiyueta(aConfig + ":eq(0) span", x, y).text().trim();
    var leftStr = "";
    var rightStr = "";
    var isSpanTime = false; //有时间
    var spanTimeType = -1;
    if (span != "") {
        if (span.substr(0, 1) == "[") {
            leftStr = "["
            span = span.substr(1);
        }
        if (span.substr(-1, 1) == ']') {
            rightStr = "]"
            span = span.substr(0, span.length - 1)
        }
    }
    var reg = /^[1-9]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/;
    var regExp = new RegExp(reg);
    if (regExp.test(span)) { //正确格式为：2014-01-01
        isSpanTime = true; //有时间
        spanTimeType = 2;
    }

    if (isSpanTime) {
        s = this.tplConfig.itemTime;
        if (spanTimeType > 0) {
            s = this.tplConfig.itemTime1;
        }
        s = leftStr + s + rightStr

    }
    xiyueta(aConfig + ":eq(0)  span", x, y).html(s); //span加time
}





//外部追加
xiyueta.fn.extend({
    tplconfig: function(configArr) { //获得模板配置信息                
        return _xyt.setTplConfig(configArr); //配置数组
    },
    nav: function(action) { //自动给导航块加程序
        return _xyt.nav(this.selector, this.x, this.y, action);
    },
    news: function(action) { //自动给新闻块加程序
        return _xyt.news(this.selector, this.x, this.y, action);
    },
    webtpl: function(tplObj) { //网页转模板网页
        return _xyt.webtpl(this.selector, tplObj);
    }

})