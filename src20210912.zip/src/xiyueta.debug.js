//网页扫描
_XIYUETA.prototype.scan = function(action) {
    if (action == undefined) action = ""; //兼容ASP
    action = "|" + action + "|"; //动作
    var lv = 0;
    var firstLevelArr = []; //一级标签数组
    var isFindLabel = false; //是否为开始找一级标签
    var c = ""; //
    var labelCheckList = "";
    var labelList = ""; //收集网页不同标签
    var arr = [];
    var charset = this.charset();
    if (charset == undefined) charset = "";
    c += "网页编码:" + charset + "\n";
    c += "网页大小:" + this.common.getFileSize(this.common.bystesLength(this.htmlSource)) + "\n";

    //处理网页双标签是否有错误 并修复
    for (var i = 0; i <= this.htmlArr.length - 1; i++) {
        var obj = this.htmlArr[i]; //标签对象
        if (obj) {
            if (obj.label.substr(0, 1) != '/' && obj.label != '') { //收集不同标签
                if (('|' + labelList + '|').indexOf('|' + obj.label + '|') == -1) {
                    if (labelList != "") labelList += "|";
                    labelList += obj.label;
                    arr[obj.label] = 1;
                } else {
                    arr[obj.label]++;
                }

            }
        }
    }
    var splxx = labelList.split("|");
    var cList = "";
    for (var i = 0; i <= splxx.length - 1; i++) {
        var s = splxx[i];
        cList += s + '=' + arr[s] + ',';
    }

    var obj = this.repairHTML();
    // console.log(obj)

    c += "网页错误标签数 " + obj.err + "\n"
    c += "网页错误标签为 " + obj.errList + "\n"
    c += "网页错误标签是否可修复 " + obj.state + "\n"
    c += "网页类型标签数 " + splxx.length + "种 " + cList + "\n"

    this.config.downcss = 0; //初始值

    var cssLink = xiyueta("link[rel|NOUL=stylesheet]").item("href");
    var jsList = xiyueta("script").item("src");
    for (var i = 0; i <= this.htmlArr.length - 1; i++) {
        var obj = this.htmlArr[i]; //标签对象
        if (obj != undefined) {
            if (obj.label == "body") {
                lv = obj.lv;
                isFindLabel = true; //找一级标签开始
            } else if (isFindLabel == false && "|div|span|table|ul|".indexOf('|' + obj.label + '|') != -1) {
                firstLevelArr.push(obj.html);
                isFindLabel = true;
            } else if (isFindLabel && obj.lv - lv == 1 && obj.tagpair == 2) { //找第一层，只针对双标签 要减去body
                if (obj.label.substr(0, 1) != "/" && obj.label != "!--" && obj.label.substr(0, 6) != "script") {
                    firstLevelArr.push(obj.html)
                }
            }
            if (obj.label == "link" && obj.rel == "stylesheet") {
                var url = this.common.fullHttpUrl(this.config.httpurl, obj.href);
                if (action.indexOf("|downcss|") != -1) {
                    if (obj.content == undefined) {
                        this.getUrlStr(obj, url); //把这个css对象的内容读取出来赋值到这里面
                        this.config.downcss++;
                        alert("下载CSS" + url)
                    }
                }
            }

        }
    }

    c += "共有CSS文件 " + cssLink.length + " 条\n"
    c += "共有JS文件 " + jsList.length + " 条\n"
    c += "一层标签共 " + firstLevelArr.length + " 条\n"

    c += "\n";
    if (cssLink != "") {
        c += "CSS列表:\n";
        for (var i = 0; i <= cssLink.length - 1; i++) {
            var url = this.common.fullHttpUrl(this.config.httpurl, cssLink[i]);
            c += url + "\n";
        }
    }
    if (jsList != "") {
        c += "\n\nJS列表:\n";
        for (var i = 0; i <= jsList.length - 1; i++) {
            var url = this.common.fullHttpUrl(this.config.httpurl, jsList[i]);
            c += url + "\n";
        }
    }
    if (firstLevelArr != "") {
        c += "\n\n一层标签列表:\n";
        for (var i = 0; i <= firstLevelArr.length - 1; i++) {
            c += firstLevelArr[i] + "\n";
        }
    }
    return c;
}

//外部追加
xiyueta.fn.extend({
    scan: function(action) { //网页扫描
        return _xyt.scan(action)
    }

})