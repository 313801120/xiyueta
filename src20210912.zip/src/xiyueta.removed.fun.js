/*
xiyueta被遗弃属性列表
 */


//获得双标签块内容20210505
_XIYUETA.prototype.getLabelHtml = function(x, y) {
    var c = "";
    for (var j = x; j <= y; j++) { //循环，除双标签开始这一条
        var obj = this.htmlArr[j];
        if (obj != undefined) {
            if (j > x) c += obj.upHtml;
            if (j > x && j < y) c += obj.html; //标签块 除标签开始与结束外   
        }
    }
    return c;
}

//移除生成模板网站时不需要的标签块
_XIYUETA.prototype.removeNotNeededLabel = function(action) {
    for (var i = 0; i <= this.htmlArr.length - 1; i++) {
        var obj = this.htmlArr[i]; //标签对象
        if (obj != undefined) {
            if (obj.label == "/script") {
                if (obj.upHtml.indexOf("hm.baidu.com/h.js") != -1) {
                    obj.upHtml = "";
                }
            }
        }
    }
}

//20210906   this.htmlArr.length!=2  对<span>aaa 不处理，因为在wrap里使用结构包裹在匹配元素集中
if (errList != "" && this.lv == 1 && this.htmlArr.length != 2 && 1 == 2) { //单独处理有一个开始标签 如  ,p,  会判断是追加 /p 还是删除这个p标签  20210906
    alert("哈哈")
    splstr = errList.split(",");
    if (splstr.length == 3) { //多一个标签
        for (var j = 1; j <= splstr.length - 2; j++) {
            var sLabel = splstr[j];
            if (sLabel.substr(0, 1) == '/') { //结束

            } else { //多一个 开始标签
                for (var i = 0; i <= this.htmlArr.length - 1; i++) {
                    obj = this.htmlArr[i]; //标签对象
                    if (obj) {
                        if (obj.label == sLabel) { //标签相等
                            for (var x = i + 1; x <= this.htmlArr.length - 1; x++) {
                                objX = this.htmlArr[x]; //标签对象
                                if (objX) {
                                    if (obj.lv == objX.lv) { //等级相等
                                        if (obj.label != objX.label.substr(1)) { //找到的结束标签与当前标签不相等
                                            if (objX.upHtml != "" || objX.nIndex - 1 > obj.nIndex) { //有内容，补齐结束标签
                                                objX.upHtml += "</" + obj.label + ">";
                                                isUpdateHTML = true; //更新HTML
                                                errList = ""; //错误清空
                                            } else { //等于删除，保留upHtml和downHtml
                                                obj.label = "";
                                                obj.html = "";
                                                obj.lv--;
                                                errList = ""; //错误清空
                                                this.reairHtmlLv(obj, -1);
                                            }
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (isUpdateHTML) { //是否需要更新
        this.parseHTML(this.printHTML()); //更新
    }
} else if (errList != "" && this.lv == 2 && 1 == 1) { //待处理这种  如 ,p,p,
    // console.log(errList)
}