﻿/*!
 * xiyueta JavaScript Library v1.*
 * http://xiyueta.com/
 * 兴趣是最好的老师，模仿是最好的学习
 */
//xiyueta.asp.js处理asp 创建于20210809
var _XIYUETAASP = function(asp) {
    "use strict"; //严格模式
    if (asp == undefined) asp = ""; //判断为无效则为空
    this.aspSource = asp; //asp源内容
    this.aspArr = []; //asp结构数组 
    this.common = new XiyuetaCommon(); //公共类
    this.config = {}; //配置
    this.phpPublicObjectList = ""; //PHP公共对象列表
    this.phpPublicFunList = ""; //PHP公司函数列表

    //ASP解析 在html解析上改进过来
    this.aspParse = function(inputAsp) {
        if (inputAsp != undefined) this.aspSource = inputAsp, this.aspArr = []; //传入HTML不为空则替换html源内容
        var s = ""; //字符
        var upS = "" //上一级字符
        var nextS = "" //下一级字符
        var lableName = ""; //标签名称
        var lableType = ""; //标签类型
        var html = ""; //字符内容
        var upHtml = ""; //上一级字符内容 
        var isNode = false //为注释 
        var isASP = false //ASP程序
        var isSelectCase = false; //设置select里的case为假
        var lv = 0; //层级
        var wc = ""; //程序里输入文本块
        var sYHCount = 0; // //双引号默认为0
        var aspFunList = ",dim,if,then,elseif,else,end,function,select,case,call,for,to,next,set,nothing,do,while,loop,and,true,false,vbcrlf,in,class,new,"; //asp函数块

        var splstr = this.aspSource.split("\n"); //换行
        for (var i = 0; i <= splstr.length - 1; i++) { //循环行
            for (var j = 0; j <= splstr[i].length; j++) { //循环字符
                upS = s; //上一个字符
                s = splstr[i].substr(j, 1); //当前字符
                nextS = splstr[i].substr(j + 1, 1); //下一个字符
                if (isASP == false) { //asp为假
                    if (s == '%' && upS == '<') { //找到ASP开头部分
                        isASP = true; //asp为真
                        this.aspArr.push({
                            lv: lv,
                            type: '<asp>',
                            label: '<%',
                            upHtml: upHtml,
                            html: "<%",
                            tagpair: 2 //为双标签
                        })
                        html = "", upHtml = "", lableName = "";
                        lv++;
                    }
                } else { //asp为真
                    if (s == '%' && nextS == '>') { //找到ASP结束部分
                        isASP = false; //asp为假
                        lv--;
                        this.aspArr.push({
                            lv: lv,
                            type: '<asp>',
                            label: '%>',
                            upHtml: upHtml,
                            html: "%>",
                            tagpair: 2 //为双标签
                        })
                        html = "", upHtml = "", lableName = "";
                        j++;
                        upS = s; //上一个字符
                        s = splstr[i].substr(j, 1); //当前字符
                        nextS = splstr[i].substr(j + 1, 1); //下一个字符

                    } else {
                        html += s; //html累加

                        //输入文本
                        if (s == '"' || wc != "") {
                            //双引号累加
                            if (s == '"') sYHCount++;
                            //判断是否"在最后
                            if (sYHCount % 2 == 0) {
                                if (nextS != '"') {
                                    wc = wc + s
                                    this.aspArr.push({
                                        lv: lv,
                                        type: "<str>",
                                        label: lableName,
                                        upHtml: upHtml,
                                        html: wc,
                                        tagpair: 2 //为双标签
                                    })
                                    sYHCount = 0, wc = "", html = "", upHtml = "", lableName = ""; //清除
                                } else {
                                    wc += s
                                }
                            } else {
                                wc += s
                            }


                        } else if (s == '(') { //左括弧
                            lv++;
                            this.aspArr.push({
                                lv: lv,
                                type: "<(>",
                                label: s,
                                upHtml: upHtml,
                                html: html,
                                tagpair: 2 //为双标签
                            })
                            html = "", upHtml = "", lableName = "";
                        } else if (s == ')') {
                            this.aspArr.push({
                                lv: lv,
                                type: "<)>",
                                label: s,
                                upHtml: upHtml,
                                html: html,
                                tagpair: 2 //为双标签
                            })
                            html = "", upHtml = "", lableName = "";
                            lv--;

                        } else if ("|&|,|+|-|*|/|=|:|>|<|".indexOf('|' + s + '|') != -1) { //特殊字符
                            this.aspArr.push({
                                lv: lv,
                                type: "<fuhao>",
                                label: s,
                                upHtml: upHtml,
                                html: html,
                                tagpair: 1 //为双标签
                            })
                            if (s == "=" || s == ">") {
                                var up2Obj = this.aspArr[this.aspArr.length - 2]; //倒数第二个    
                                if (up2Obj.label == ">" || up2Obj.label == "<") {
                                    up2Obj.label += s;
                                    up2Obj.html += " " + s;
                                    this.aspArr.pop(); //删除最后一条数组
                                }
                            }
                            html = "", upHtml = "", lableName = "";

                        } else if (s == "'") { //注释
                            this.aspArr.push({
                                lv: lv,
                                type: "<note>",
                                label: s,
                                upHtml: html,
                                html: splstr[i].substr(j + 1),
                                tagpair: 1 //为双标签
                            })
                            html = "", upHtml = "", lableName = "";
                            break;
                        } else if (s != "" && s != " " && s != '\t' && ("' ()+-*/=><&,".indexOf(nextS) != -1 || j == splstr[i].length)) {
                            lableName += s.toLowerCase(); //转小写
                            if ("0123456789".indexOf(lableName.substr(0, 1)) != -1) { //提取第一个字符判断是否为数字类型
                                lableType = "<int>";
                            } else if (nextS == '(' || aspFunList.indexOf(',' + lableName + ',') != -1 || lableName.indexOf(".") != -1) {
                                lableType = "<fun>"
                            } else {
                                lableType = "<var>"
                            }
                            this.aspArr.push({
                                lv: lv,
                                type: lableType,
                                label: lableName,
                                upHtml: upHtml,
                                html: html,
                                tagpair: 2 //为双标签
                            })
                            if (lableName == 'function') {
                                var upObj = this.aspArr[this.aspArr.length - 2]; //倒数第二个   
                                if (upObj.label == "end") { //结束标签
                                    lv--;
                                    upObj.lv--;
                                    upObj.label += "function";
                                    upObj.html += " function";
                                    this.aspArr.pop(); //删除最后一条数组
                                } else {
                                    lv++; //定义函数累加
                                }

                            } else if (lableName == 'if') {
                                var upObj = this.aspArr[this.aspArr.length - 2]; //倒数第二个   
                                if (upObj.label == "end") { //结束标签
                                    lv--;
                                    upObj.lv--;
                                    upObj.label += "if";
                                    upObj.html += " if";
                                    this.aspArr.pop(); //删除最后一条数组
                                } else {
                                    lv++; //定义函数累加
                                }
                            } else if (lableName == 'else' || lableName == 'elseif' || lableName == 'then') {
                                var obj = this.aspArr[this.aspArr.length - 1];; //最后一个
                                obj.lv--;
                                if (lableName == 'else') { //select
                                    var upObj = this.aspArr[this.aspArr.length - 2]; //倒数第二个  
                                    if (upObj.label == "case") {
                                        upObj.lv;
                                        upObj.label += "else";
                                        upObj.html += " else";
                                        this.aspArr.pop(); //删除最后一条数组
                                    }
                                }


                            } else if (lableName == 'select') {
                                var upObj = this.aspArr[this.aspArr.length - 2]; //倒数第二个   
                                if (upObj.label == "end") { //结束标签
                                    lv--;
                                    upObj.lv--;
                                    upObj.label += "select";
                                    upObj.html += " select";
                                    this.aspArr.pop(); //删除最后一条数组
                                    if (isSelectCase) {
                                        isSelectCase = false; //设置select里的case为假
                                        lv--; //再退一格，退出 case
                                        upObj.lv--;
                                    }
                                } else {
                                    lv++; //定义函数累加
                                }
                            } else if (lableName == 'case') {
                                var up2Obj = this.aspArr[this.aspArr.length - 2]; //倒数第二个   
                                if (up2Obj.label == "select") { //结束标签                                         
                                    up2Obj.label += "case";
                                    up2Obj.html += " case";
                                    this.aspArr.pop(); //删除最后一条数组
                                } else {
                                    if (isSelectCase) {
                                        var up1Obj = this.aspArr[this.aspArr.length - 1]; //倒数第1个
                                        up1Obj.lv--;
                                    } else {
                                        lv++;
                                        isSelectCase = true; //为真
                                    }
                                }

                            } else if (lableName == 'class') {
                                var upObj = this.aspArr[this.aspArr.length - 2]; //倒数第二个   
                                if (upObj.label == "end") { //结束标签
                                    lv--;
                                    upObj.lv--;
                                    upObj.label += "class";
                                    upObj.html += " class";
                                    this.aspArr.pop(); //删除最后一条数组
                                } else {
                                    lv++; //定义函数累加
                                }

                            } else if (lableName == 'each') {
                                var up2Obj = this.aspArr[this.aspArr.length - 2]; //倒数第二个   
                                if (up2Obj.label == "for") { //结束标签
                                    up2Obj.label += "each";
                                    up2Obj.html += " each";
                                    this.aspArr.pop(); //删除最后一条数组
                                }
                            } else if (lableName == 'while') { //do while循环
                                var up2Obj = this.aspArr[this.aspArr.length - 2]; //倒数第二个  
                                if (up2Obj.label == "do") {
                                    up2Obj.label += "while";
                                    up2Obj.html += " while";
                                    this.aspArr.pop(); //删除最后一条数组
                                }

                                lv++; //定义函数累加

                            } else if (lableName == 'loop') { //do while循环
                                var obj = this.aspArr[this.aspArr.length - 1];; //最后一个
                                lv--; //定义函数累加
                                obj.lv--;

                            } else if (lableName == 'for') {
                                lv++;
                            } else if (lableName == 'next') {
                                lv--;
                                var obj = this.aspArr[this.aspArr.length - 1];; //最后一个
                                obj.lv--;
                            }






                            html = "", upHtml = "", lableName = "", lableType = "";



                        } else if (s != " " && s != "\t") { //标签名累加
                            lableName += s.toLowerCase(); //转小写
                        }
                    }

                }
            }

            if (i + 1 < splstr.length) { //最后一条就不处理了
                //换行
                this.aspArr.push({
                    lv: lv,
                    type: "<br>",
                    label: "\n",
                    upHtml: "",
                    html: "\n",
                    tagpair: 1 //为单标签
                })
            }

        }
    }
    //转PHP
    this.tophp = function(type) {
        var c = "";
        var rowC = ""; //第一条内容
        var obj = []; //当前对象
        var upObj = []; //上一个对象
        var nextObj = []; //下一个对象
        var nAddLv = 0; //退格 如     if
        var isIfJiSuan = false; //为IF括弧里为假 只有在 if(里的=号是==号)
        var isDim = false; //为定义变量
        var forStat = ""; //for状态
        var forDim = ""; //for定义变量
        var selectStat = ""; //select状态
        var isDictionaryAdd = false; //为字典添加值
        var nFangKuoHao = -1; //方括号[ ]真
        var nDaKuoHao = -1; //大括弧{} 
        var isWhile = false; //为While循环
        var nSplit = -1; //split切换块处理
        var splitStart = ""; //split里面第一个参数部分
        var sArrayList = ","; //数组定义，如 $obj['aa']
        var sFunList = "," + this.phpPublicFunList; //函数列表，函数不前面不加$
        var sObjectList = "," + this.phpPublicObjectList; //class类对象列表 return 
        var nSelectCase = -1; //这个位置的：号不处理，要是没有则加上
        var isSelectCase = false; //select里case最后加上break;

        for (var i = 0; i <= this.aspArr.length - 1; i++) {
            //处理select里csse分号 有则加上就跳过，没则加上
            if (nSelectCase == i) {
                obj = this.aspArr[i];
                if (obj.label == ":") {
                    rowC += ":";
                    i++;
                } else {
                    rowC += ":";
                }
                nSelectCase = -1;
            }
            if (i > 0) upObj = this.aspArr[i - 1]; //上一个对象
            obj = this.aspArr[i];
            nextObj = []; //下一个对象
            if (i < this.aspArr.length) {
                nextObj = this.aspArr[i + 1];
            }
            if (upObj.type == "<br>") {
                rowC += this.common.copyStr("    ", obj.lv + nAddLv); //退格数
            }

            if (obj.label == "<%") { //ASP开始
                rowC += "<?PHP";
                nAddLv--; //退格用

            } else if (obj.label == "%>") { //ASP结束
                rowC += "?>";
            } else if (obj.type == "<br>") { //换行
                rowC += "\n";
            } else if (obj.type == "<note>") { //换行
                rowC += "//" + obj.html;
            } else if (obj.type == "<var>") { //定义变量
                var isMenHao = true; //是否加分号
                if (sFunList.indexOf(',' + obj.label + ",") != -1) { //变量在函数列表里
                    if (upObj.label == "class") { //如 class mycls() 加{
                        isMenHao = false;
                        rowC += obj.label + "{";
                    } else if (upObj.label == "new") {
                        rowC += obj.label + "()"
                    } else if (nextObj.label == "=") {
                        rowC += "return ";
                        i++;
                    } else {
                        rowC += obj.label;
                    }


                } else {
                    rowC += "$" + obj.label;
                }
                if (nextObj.type == "<br>" && selectStat == "" && isMenHao) rowC += ";";
                //符号，数字类型
            } else if (obj.type == "<fuhao>" || obj.type == "<int>" || obj.type == "<(>" || obj.type == "<)>") {
                if (isIfJiSuan && obj.label == "=") { //if(=)的等号  for里第一个=号不需要处理
                    rowC += "==";
                } else if (obj.label == "&") { //连接符
                    rowC += ".";
                } else if (obj.label == "(") { //左括弧
                    if (nFangKuoHao == obj.lv) { //改[
                        rowC += "[";
                    } else {
                        rowC += "(";
                    }
                } else if (obj.label == ")") { //方括号[ ]
                    if (nFangKuoHao == obj.lv) { //方括号
                        rowC += "]";
                        nFangKuoHao = -1;
                    } else if (nSplit == obj.lv) { //split切割
                        c += rowC + "," + splitStart + ")";
                        rowC = "", nSplit = -1, splitStart = "";
                    } else if (nDaKuoHao == obj.lv) { //大括弧{
                        nDaKuoHao = -1;
                        rowC += "){"
                    } else {
                        rowC += ")";
                    }

                    if (nextObj.type == "<br>" || nextObj.type == "<note>") rowC += ";"; //在行最后加分号
                } else if (obj.label == ",") { //逗号
                    if (isDictionaryAdd) { //字典添加值
                        rowC += "]=";
                        isDictionaryAdd = false; //操作后为假了
                    } else if (nSplit == obj.lv) { //split分割 处理分割与被分割位置互换
                        splitStart = rowC, rowC = "";
                    } else if (isDim) {
                        rowC += ";";
                        //下一个数组类型为换行或注释则为假
                        if (nextObj.type == "<br>" || nextObj.type == "<note>") isDim = false;
                    } else {
                        rowC += ",";
                    }
                } else if (obj.label == ":") { //冒号
                    rowC += ";";
                } else if (obj.label == "<>") { //不等于
                    rowC += "!=";
                } else if (obj.type == "<int>") { //冒号
                    rowC += obj.label;
                    if ((nextObj.type == "<br>" || nextObj.type == "<note>") && nSelectCase == -1) rowC += ";";
                } else {
                    rowC += obj.label;
                }

            } else if (obj.type == "<str>") { //字符串类型
                rowC += obj.html;
                if ((nextObj.type == "<br>" || nextObj.type == "<note>") && nSelectCase == -1) rowC += ";";
            } else if (obj.type == "<fun>") { //函数类型
                if (obj.label == "response.write") {
                    rowC += "echo";
                } else if (obj.label == "nothing") {
                    rowC += "null";
                } else if (obj.label == "and") {
                    rowC += " && ";
                } else if (obj.label == "ubound") {
                    rowC += "count";
                } else if (obj.label == "split") {
                    var up2Obj = this.aspArr[i - 2]; //上2个对象
                    sArrayList += up2Obj.label + ".add," //追加数组，加.add是为了判断方便
                    rowC += "explode(";
                    c += rowC, rowC = "";
                    nSplit = obj.lv + 1; //切割查的位置
                    i++;
                } else if (obj.label == "new") { //new后面加一个空格
                    rowC += "new "
                } else if (obj.label == "function") { //函数开始
                    var next2Obj = this.aspArr[i + 2]; //上2个对象
                    nDaKuoHao = next2Obj.lv; //大括弧位置 为了在函数定义后加{
                    rowC += obj.label + " "; //定义函数后面加个空格
                    if (sFunList.indexOf(',' + nextObj.label + ',') == -1) sFunList += nextObj.label + ','; //追加函数到列表

                } else if (obj.label == "endfunction") { //函数开始 
                    rowC += "}";

                } else if (obj.label == "if") {
                    rowC += obj.label;
                    if (nextObj.label != "(") rowC += "(";
                    isIfJiSuan = true; //为IF里计算为真
                } else if (obj.label == "elseif") {
                    rowC += "}else if";
                    if (nextObj.label != "(") rowC += "(";
                    isIfJiSuan = true; //为IF里计算为真
                } else if (obj.label == "then") {
                    if (upObj.label != ")") rowC += ")";
                    rowC += "{";
                    isIfJiSuan = false; //为IF里计算为假
                } else if (obj.label == "else") {
                    rowC += "}else{";
                } else if (obj.label == "endif") {
                    rowC += "}";

                } else if (obj.label == "selectcase") {
                    rowC += "switch ";
                    if (nextObj.label != "(") rowC += "(";
                    selectStat = "selectcase";
                } else if (obj.label == "endselect") {
                    rowC += "}";
                    if (isSelectCase) c += this.common.copyStr("    ", obj.lv + 1) + 'break;\n';
                    isSelectCase = false; //select里cse为假
                } else if (obj.label == "caseelse") {
                    rowC += "default "
                    if (isSelectCase) c += this.common.copyStr("    ", obj.lv) + 'break;\n';
                    isSelectCase = true; //select里cse为真
                    nSelectCase = i + 1; //这个位置的：号不处理，要是没有则加上
                } else if (obj.label == "case") {
                    rowC += obj.label + " ";
                    if (isSelectCase) c += this.common.copyStr("    ", obj.lv) + 'break;\n';
                    isSelectCase = true; //select里cse为真
                    nSelectCase = i + 2; //这个位置的：号不处理，要是没有则加上
                } else if (obj.label == "vbcrlf") {
                    rowC += '"\\n"';

                } else if (obj.label == "createobject") {
                    if (i - 1 > 0) { //获得对象名称
                        var up2Obj = this.aspArr[i - 2]; //上2个对象
                        sArrayList += up2Obj.label + ".add,"
                    }
                    if (i + 1 < this.aspArr.length) { //为字典处理
                        var next2Obj = this.aspArr[i + 2];
                        if (next2Obj.html.toLowerCase() == '"scripting.dictionary"') {
                            rowC += "array();"
                            i += 3;
                        }
                    }
                } else if (sArrayList.indexOf(',' + obj.label + ',') != -1) { // 如  obj.add
                    rowC += "$" + obj.label.substr(0, obj.label.indexOf(".")) + "[";
                    var next2Obj = this.aspArr[i + 2];
                    if (next2Obj.label == ",") {
                        isDictionaryAdd = true; //为字典添加值
                    }
                } else if (sArrayList.indexOf(',' + obj.label + '.') != -1) { //对象
                    rowC += "$" + obj.label;
                    nFangKuoHao = nextObj.lv; //需要加方括号位置

                } else if (obj.label == "dowhile") {
                    rowC += "while";
                    if (nextObj.label != "(") rowC += "(";
                    isWhile = true; //为While循环
                } else if (obj.label == "loop") {
                    rowC += "}";

                } else if (obj.label == "class") {
                    rowC += "class ";
                    if (sFunList.indexOf(',' + nextObj.label + ",") == -1) {
                        sFunList += nextObj.label + ","
                    }
                    if (sObjectList.indexOf(',' + nextObj.label + ',') == -1) { //追加Class类对象名称
                        sObjectList += nextObj.label + ",";
                    }
                } else if (obj.label == "endclass") {
                    rowC += "}";


                } else if (obj.label == "foreach") { //foreach
                    var next1Obj = this.aspArr[i + 1];
                    var next3Obj = this.aspArr[i + 3];
                    rowC += "foreach($" + next3Obj.label + " as $key=>$" + next1Obj.label + "){";
                    i += 3;
                } else if (obj.label == "for") {
                    rowC += obj.label;
                    if (nextObj.label != "(") rowC += "(";
                    forStat = "for"
                    forDim = nextObj.label;
                } else if (forStat == "for" && obj.label == "to") {
                    var next1Obj = this.aspArr[i + 1];
                    if (nextObj.label == "ubound") {
                        rowC += ";$" + forDim + "<";
                    } else {
                        rowC += ";$" + forDim + "<=";
                    }
                    forStat = "forto"
                } else if (obj.label == "next") {
                    rowC += "}";
                } else if (obj.label == "dim") {
                    isDim = true; //程序里定义变量

                } else if (obj.label.indexOf(".") != -1) { //最后处理这种  aa.bb（
                    rowC += '$' + obj.label.replace(/\./g, "->");
                } else if (",call,set,".indexOf(',' + obj.label + ',') == -1) {
                    rowC += obj.label;
                }

                if (nextObj.type == "<br>") {
                    if (",endfunction,then,endif,next,else,endselect,endclass,".indexOf(',' + obj.label + ',') == -1 && isWhile == false) {
                        rowC += ";";
                    }
                }
            }
            //最后换行
            if (forStat == "forto" && (nextObj.type == "<br>" || nextObj.type == "<note>") && obj.label != "to") { //for循环判断结束
                if (nextObj.type == "<note>") rowC += ";"; //加分号，因为循环判断最后是一个注释
                rowC += '$' + forDim + "++";
                forStat = "", forDim = "";
                if (upObj.label != ")") rowC += ")";
                rowC += "{";
            } else if (selectStat == "selectcase" && (nextObj.type == "<br>" || nextObj.type == "<note>") && obj.label != "selectcase") { //for循环判断结束
                selectStat = "";
                if (upObj.label != ")") rowC += ")";
                rowC += "{";
            } else if (isWhile && (nextObj.type == "<br>" || nextObj.type == "<note>")) { //while循环
                isWhile = false;
                if (upObj.label != ")") rowC += ")";
                rowC += "{";
                isIfJiSuan = false; //为IF里计算为假，下一个为换行则为假
            }

            if (obj.type == "<br>") { //换行
                c += rowC, rowC = "";
                isDim = false; //换行了清空变量定义
            }
        }
        return c + rowC;
    }
    //美妇ASP 
    this.aspBeautify = function() {
        for (var i = 0; i <= this.aspArr.length - 1; i++) {
            var obj = this.aspArr[i];
            if (obj.label == "class") {
                if (i < this.aspArr.length) {
                    var nextObj = this.aspArr[i + 1];
                    this.phpPublicObjectList += nextObj.label + ",";
                    this.phpPublicFunList += nextObj.label + ",";
                }
            }
        }
    }

    //测试
    this.debug = function() {
        console.log(this.aspArr);
    }
}


var _xytasp = new _XIYUETAASP();
//用法 xiyuetaASP().tophp();
xiyuetaASP = $xytasp = $asp = function(config) {
    return {
        parse: function(asp) { //解析ASP
            _xytasp.aspParse(asp);
            return this;
        },
        beautify: function() { //美化ASP
            _xytasp.aspBeautify(config);
            return this;
        },
        tophp: function(type) { //ASP转PHP代码
            return _xytasp.tophp(type);;
        },
        debug: function(value) { //调试
            return _xytasp.debug(value);
        }
    }
}