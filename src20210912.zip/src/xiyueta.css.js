﻿/*!
 * xiyueta JavaScript Library v1.*
 * http://xiyueta.com/
 * 兴趣是最好的老师，模仿是最好的学习
 */

//xiyueta.css处理css  创建于20210429
var _XIYUETACSS = function(css) {
    "use strict"; //严格模式
    if (css == undefined) css = ""; //判断为无效则为空
    this.cssSource = css; //html源内容
    this.cssArr = []; //html结构数组
    this.common = new XiyuetaCommon(); //xiyueta公共函数库
    this.config = {
        parentdir: "../", //上一级目录 根据CSS位置来退格
        imagesdir: "images/"
    };

    //CSS解析 在html解析上改进过来
    this.cssParse = function(inputCss) {
        if (inputCss != undefined) this.cssSource = inputCss, this.cssArr = []; //传入CSS不为空则替换CSS源内容
        var s = ""; //字符
        var upS = "" //上一级字符
        var lableName = ""; //标签名称
        var html = ""; //字符内容
        var upHtml = ""; //上一级字符内容
        var isLabel = false //是否为标签
        var isLabelName = false //是否为标签名称 
        var isEndLabel = false //是否为开始或结束标签 <ul>或</ul>
        var isNode = false //为注释
        var isAiTe = false; //是否为@打头
        var isCharset = false; //css编码
        var lv = 0; //层级
        for (var i = 0; i <= this.cssSource.length - 1; i++) { //逐个循环html源内容
            upS = s;
            s = this.cssSource.substr(i, 1);
            if (isLabel) { //为标签 如<a href='1.asp'>   第二步
                html += s; //html累加标签 
                if (isNode) { //注释为真处理部分
                    if (s == "/" && upS == "*") { //为注释结束
                        isNode = false; //注释为假
                        isLabel = false; //标签为假
                        isEndLabel = false; //标签结果为假
                        this.cssArr.push({
                            lv: 1,
                            label: '/*',
                            upHtml: upHtml,
                            html: html
                        }) //注释写入数组   标签为/*
                        html = "", upHtml = "";
                    }
                } else if (isLabelName && s == "*" && upS == "/") { //为注释  <!-- 注释内容 -->
                    isNode = true;

                } else if (isAiTe) { //为@打开为真  
                    if (isCharset && (s == ";" || s == "\n")) { //编码结束
                        isCharset = false; //是否为编码为假
                        isLabelName = false; //是标签名称为假
                        isLabel = false; //是标签为假
                        isAiTe = false; //@为假
                        this.cssArr.push({
                            lv: 1,
                            label: lableName.toLowerCase().trim(),
                            upHtml: upHtml,
                            html: html
                        }) //追加数组
                        html = "", upHtml = ""; //清空html和上一级html
                    } else if (s == " " && isLabelName) { //当为空格时 则不收录标签名了
                        if (html.toLowerCase() == "@charset ") {
                            isCharset = true; //为网页编码
                            isLabelName = false;
                        } else if (html.toLowerCase() == "@font-face ") { //这种退出，还是属于一级，没有子级
                            isAiTe = false; //退出
                        }


                    } else if (s == "{") { //为@打开{
                        if (html.toLowerCase() == "@font-face ") { //这种退出，还是属于一级，没有子级
                            isAiTe = false; //退出
                        } else {
                            isLabelName = false; //是标签名称为假
                            isLabel = false; //是标签为假
                            isAiTe = false; //@为假
                            this.cssArr.push({
                                lv: 1,
                                label: lableName.toLowerCase().trim(),
                                upHtml: upHtml,
                                html: html
                            }) //追加数组
                            lv++;
                            html = "", upHtml = ""; //清空html和上一级html
                        }
                    }

                } else if (s == "{" && isLabelName) { //提取标签名 
                    isLabelName = false
                } else if (s == "}") { //标签结束              第四步
                    isLabelName = false; //是标签名称为假
                    isLabel = false; //是标签为假
                    this.cssArr.push({
                        lv: lv + 1,
                        label: lableName.toLowerCase().trim(),
                        upHtml: upHtml,
                        html: html
                    }) //追加数组
                    html = "", upHtml = ""; //清空html和上一级html
                }

                if (isLabelName) {
                    if (s == " " && (upS == " " || upS == ",")) { //当前字符为空时，上一个字符为空或为,号时就不处理了，让标签完整
                    } else {
                        lableName += s; //标签名称累加
                    }
                }



            } else if (s != " " && s != ";" && s != "\n") { //标签开始  第一步
                if (s == "}" && lv == 1) { //一层结束
                    this.cssArr.push({
                        lv: lv,
                        label: "}",
                        upHtml: upHtml,
                        html: "}"
                    }) //追加数组
                    html = "", upHtml = ""; //清空html和上一级html
                    lv--;

                } else {
                    upHtml = html; //保留上一级内容
                    html = s; //html开始记录
                    isLabel = true
                    isLabelName = true;
                    isEndLabel = false; //是开始标签还是结束标签  <ul>或</ul>
                    lableName = s; //当前字符为标签名第一个字符
                    if (s == "@") isAiTe = true; //为@打头
                }


            } else { //html内容累加
                html += s; //html累加
            }
        }


        if (html != "") { //最后css不为空则追加
            this.cssArr.push({
                lv: lv,
                label: '',
                upHtml: "",
                html: html
            })
        }

    }
    //获得CSS标签对象指定参数值或替换参数值
    this.handleLabelParam = function(obj, param, value) { //操作对象，参数名称，这里不param= '[All]' 是为了兼容ASP
        if (param == undefined) param = '[All]'; //这样做是为了在ASP运行
        if (value == undefined) { //赋值为无效时则为获得参数值
            if (obj[param] != undefined) return obj[param]; //参数属性存在则直接输出参数值   
        }
        var action = ""; //动作
        if (param.indexOf("|") != -1) {
            var splxx = param.split("|");
            param = splxx[0];
            action = splxx[1];
            if (param == "") param = "[All]";

        }
        var n = obj.html.indexOf("{") + 1; //从标签的{后面找参数与参数值             
        var isParam = false; //是否为参数
        var paramName = ""; //参数名
        var paramValue = ""; //参数值
        var isValue = false; //是否为内容
        var yinHaoType = ""; //单双引号类型
        var isYinHao = false; //是否为引号  有的参数没有单双引号 如 <a href=1.jpg>
        var isValidYinHao = true; //是否有效引号，有时可能为空 如 <a name=xx>  
        var nStartPosition = 0; //参数值开始位置
        var iskuoHu = false; //括弧
        var c = "";
        for (var i = n; i <= obj.html.length - 1; i++) { //循环标签串 如 <a href='1.jpg'>
            var s = obj.html.substr(i, 1);
            if (isValue) { //提取参数值为真  第三步
                if (isYinHao) { //单双引号为真
                    if (iskuoHu == true && s == ")") iskuoHu = false; //处理()部分，不处理这里面的内容
                    if (iskuoHu == false && (s == yinHaoType || s == "}" || i == obj.html.length - 1)) { //当前字符和引号相等或在标签最后  或在最后   i==obj.html.length-1 20210514
                        // alert("yinHaoType="+yinHaoType)
                        paramName = paramName.toLowerCase().trim(); //标签名转小写 去两边空格，防止换行那种2010507
                        obj[paramName] = paramValue; //参数值写对数据里，下次就不用再找了
                        isValue = false; //参数值为假
                        isYinHao = false; //单双引号为假
                        yinHaoType = ""; //单双引号为空 
                        if (param == paramName || param == "[All]") { //当前标签参数名与搜索参数名相等
                            if (value == undefined) { //为查找 
                                if (action == "url") { //url查的，只要这个css里有多少个url多提取
                                    paramValue = this.getSetCssBg(paramValue); //当前出现动作为url时 20210509   
                                    if (paramValue != "") {
                                        if (c != "") c += "\n";
                                        c += paramValue;
                                    }
                                } else {
                                    return paramValue; //找到指值则退出
                                }
                            } else { //为替换
                                var nStart = nStartPosition; //参数值前面部分
                                var nEnd = nStartPosition + paramValue.length; //参数值后面部分
                                if (isValidYinHao) { //为有效的单双引号 修复于20210428
                                    nStart++;
                                    nEnd++;
                                }
                                var head = obj.html.substr(0, nStart); //参数内容开始位置，+1去除前面单双引号
                                var foot = obj.html.substr(nEnd); //参数内容以后内容 
                                if (action == "url") {
                                    var vS = this.getSetCssBg(paramValue, value); //当前出现动作为url时 20210509    
                                    if (vS != "") {
                                        if (c != "") c += "\n";
                                        c += vS;
                                        var sTH = head + vS + foot; //替换新内容
                                        obj.html = sTH;
                                        obj[paramName] = vS; //追加参数值
                                        i = (head + vS).length;
                                        return obj;
                                    }
                                } else {
                                    var sTH = head + value + foot; //替换新内容
                                    obj.html = sTH;
                                    obj[paramName] = value; //追加参数值
                                    return obj;
                                }

                            }
                        }

                    } else {
                        paramValue += s;
                        if (s == '(') { //20210527
                            iskuoHu = true;
                        }
                    }

                } else if (s != ' ') {
                    yinHaoType = ";"; //单双引号  它没有单双引号，以;来判断结束一个参数
                    isYinHao = true;
                    nStartPosition = i; //记录参数值开始位置 
                    isValidYinHao = false; //为有效单双引号 
                    paramValue = s; //参数值第一个字符


                }
            } else if (isParam) { //第二步
                if (s == ":") {
                    isParam = false; //找参数名为假
                    isValue = true; //找参数值为真
                    paramValue = ""; //开始收集参数内容
                    yinHaoType = ""; //单双引号 

                } else if (s != " ") { //参数名不收录空格
                    paramName += s;
                }
            } else if (s != " ") { //为找到参数名称             第一步
                isParam = true; //找到参数名，开始收集参数名称
                paramName = s;
            }
        }
        if (value != undefined) { //为添加新参数名与值20210822
            obj.html = obj.html.replace("{", '{' + param + ':' + value + '' + ';');
        }
        return c;

    }

    //获得和设置CSS标签参数值
    this.getSetCss = function(labelName, findParamName, setParamValue) {
        if (labelName == undefined) labelName = "[All]"; //兼容ASP里运行20210824

        labelName = labelName.trim(); //去除两边空格
        for (var i = 0; i <= this.cssArr.length - 1; i++) {
            var obj = this.cssArr[i];
            if (obj != undefined) {
                if (labelName == obj.label || labelName == "[All]") { //标签相等
                    if (findParamName == undefined) { //查找参数名为空则输出全部标签块
                        return obj.html;
                    } else {
                        return this.handleLabelParam(obj, findParamName, setParamValue); //为替换
                    }
                }
            } 
        }
    }

    this.getSetCssBg = function(cssValue, setParamValue) {
        if (cssValue.indexOf(",") == -1) return this.handleCssBg(cssValue, setParamValue);
        var splxx = cssValue.split(",")
        var c = "";
        for (var i = 0; i < splxx.length; i++) {
            var s = splxx[i];
            s = this.handleCssBg(s, setParamValue);
            if (c != '') c += ",";
            c += s;
        }
        return c;
    }

    //获得和设置CSS标签参数值20210509
    this.handleCssBg = function(cssValue, setParamValue) {
        if (cssValue == undefined) return "";
        if (setParamValue == undefined) { //加个判断20210527  下面代码我迷糊
            if (cssValue.indexOf("(") == -1 || cssValue.indexOf(")") == -1) {
                if (setParamValue != undefined) {
                    if (setParamValue.substr(0, 4) == "dir=" || setParamValue.substr(0, 7) == "server=") cssValue = "";
                    return cssValue;
                } else {
                    return "";
                }
            }
            var tempCssValue = cssValue.toLowerCase();
            if (tempCssValue.indexOf("url") == -1) {
                if (setParamValue != undefined) {
                    if (setParamValue.substr(0, 4) == "dir=" || setParamValue.substr(0, 7) == "server=") cssValue = "";
                    return cssValue;
                } else {
                    return "";
                }
            }
        }
        var label = ""; //标签
        var code = "";
        var isLabel = false;
        var isUrl = false;
        var isValidYinHao = false; //是否有引号
        var yinHaoType = ""; //单双引号类型
        var valueStart = -1; //值开始位置
        for (var i = 0; i <= cssValue.length - 1; i++) {
            var s = cssValue.substr(i, 1);
            if (isUrl) {
                if (isValidYinHao) { //结束
                    if (yinHaoType == s) { //单双引号 
                        var c = cssValue.substr(valueStart, i - valueStart);
                        if (setParamValue != undefined) { //替换                                 
                            if (setParamValue.substr(0, 7) == "server=") { //网址完整
                                if (c.indexOf("data:") == -1) { //除了这种不处理
                                    c = cssValue.substr(0, valueStart) + this.common.fullHttpUrl(setParamValue.substr(7), c) + cssValue.substr(i);
                                } else {
                                    return cssValue;
                                }
                            } else if (setParamValue.substr(0, 4) == "dir=") { //网址完整
                                if (c.indexOf("data:") == -1) { //除了这种不处理
                                    c = cssValue.substr(0, valueStart) + setParamValue.substr(4) + this.common.getUrlFileName(c) + cssValue.substr(i);
                                } else {
                                    return cssValue;
                                }
                            } else {
                                if (c.indexOf("data:") == -1) { //除了这种不处理
                                    c = cssValue.substr(0, valueStart) + setParamValue + cssValue.substr(i);
                                }
                            }

                        }
                        return c;
                    }

                } else if (s != "") {
                    if (s == '"' || s == "'") {
                        isValidYinHao = true; //有双引号
                        yinHaoType = s;
                        if (valueStart == -1) {
                            valueStart = i + 1;
                        }
                    } else {
                        isValidYinHao = true; //有双引号
                        yinHaoType = ")";
                        if (valueStart == -1) valueStart = i;
                    }
                }

            } else if (s == "(") {
                if (code.trim().toLowerCase().substr(-3, 3) == "url") { //从后往前提取，然后来判断
                    isUrl = true;
                } else if (setParamValue == undefined) {
                    return "";
                }


            } else {
                code += s;
            }
        }

        return cssValue;
    }



    //获得和设置全部CSS标签参数值20210503
    this.getSetAllCss = function(labelName, findParamName, setParamValue) {
        if (labelName == undefined) labelName = "[All]"; //兼容ASP里运行
        labelName = labelName.trim(); //去除两边空格
        var sFindA = ',' + labelName + ',';
        var c = "";
        for (var i = 0; i <= this.cssArr.length - 1; i++) {
            var obj = this.cssArr[i];
            if (obj != undefined) {
                var sA = ',' + obj.label + ',';
                var sB = ',' + obj.label + ' ';
                if (sA.indexOf(sFindA) != -1 || labelName == "[All]") { //标签相等
                    if (findParamName == undefined) { //查找参数名为空则输出全部标签块
                        if (c != '') c += '\n';
                        c += obj.html;
                    } else {
                        var xObj = this.handleLabelParam(obj, findParamName, setParamValue); //为查的和替换 
                        if (typeof(xObj) == "object") { //返回替换成功
                            if (c != '') c += '\n';
                            c += obj.html;
                        } else if (xObj) {
                            if (c != '') c += '\n';
                            c += xObj;
                        }
                    }
                }
            }
        }
        return c;
    }

    //获得或设置CSS样式文件里编码
    this.handleCssCharset = function(value) {
        for (var i = 0; i <= this.cssArr.length - 1; i++) {
            var obj = this.cssArr[i]; //标签对象
            if (obj != undefined) {
                if (obj.label == "@charset") {
                    if (value != undefined) { //CSS样式文件编码
                        obj.html = '@charset "' + value + '";';
                        return ""; //退出
                    }
                    var paramValue = obj.html.substr(9);
                    paramValue = paramValue.replace(/"/g, "").replace(/'/g, "").replace(/;/g, "").trim().toLowerCase();
                    return paramValue; //返回找到的CSS样式文件编码
                }
            }
        }
        return "";
    }



    //图片CSS背景图片
    this.handleCssBackGround = function(action, httpurl) {
        if (httpurl == undefined) httpurl = ""; //兼容ASP
        var c = "";
        var s, tempS, rel, sDown;
        var isWeb = true; //是否为网页需要的网址
        var isBgImg = false; //是否是背景图片

        xiyuetaCSS().allcss("|url", "server=" + httpurl); //    全部css都让有url的链接完整
        var c = xiyuetaCSS().allcss("|url");
        c = c.replace(/,/g, "\n"); //处理下 对字体处理

        xiyuetaCSS().allcss("|url", "dir=" + this.config.parentdir + this.config.imagesdir);
        var splstr = c.split("\n")
        var downlist = "";
        for (var i = 0; i <= splstr.length - 1; i++) {
            var s = splstr[i];
            if (s != "") {
                if (downlist != "") downlist += "[,]"; //分割
                if (s.indexOf("?") != -1) s = s.substr(0, s.indexOf("?"));
                downlist += s + "[|]" + this.config.parentdir + this.config.imagesdir + xiyueta.getUrlFileName(s); //先退出css目录，再加入images
            }
        }
        return downlist;
    }

    //设置配置20210501
    this.setConfig = function(configArr) {
        if (configArr == undefined) return this.config; //返回 读配置数组

        if (configArr.imagesdir != undefined) {
            this.config.imagesdir = configArr.imagesdir;
            var splxx = configArr.cssdir.split('/'); //是退出css目录  要做到先退出css目录，再进入图片目录 就正确了
            var c = "";
            for (var i = 0; i <= splxx.length - 2; i++) {
                c += "../"
            }
            this.config.parentdir = c; //上级退格目录CSS文件里需要这个 如 ../../../  
        }
        //退到上一级   如 ../../
        if (configArr.parentdir != undefined) {
            this.config.parentdir = configArr.parentdir;
        }
    }

    //获得处理完成Css内容
    this.printCss = function(action) {
        var c = "";
        for (var i = 0; i <= this.cssArr.length - 1; i++) {
            var obj = this.cssArr[i]
            if (obj != undefined) {
                var s = obj.upHtml + obj.html;
                if (action == "zip") {
                    if (obj.label == "/*") {
                        s = "";
                    } else {
                        s = s.replace(/  /g, " ").replace(/  /g, " ").replace(/{ /g, "{").replace(/ {/g, "{").replace(/\n/g, "").trim();
                    }
                } else if (action == "format") {
                    s = s.trim() + "\n";
                }
                if (s != "") c += s
            }
        }
        return c;
    }
    //CSS测试
    this.debug = function(isIE) {
        if (isIE == undefined) isIE = false;
        if (isIE) {
            xiyueta.log(this.cssArr);//在浏览器里显示
        } else {
            console.log(this.cssArr);//在浏览器调试面板里显示
        }
    }
}


var _xytcss = new _XIYUETACSS();

var xiyuetaCss = function(config, x, y) {
    return new xiyuetaCss.fn.init(config, x, y);
};
xiyuetaCss.fn = xiyuetaCss.prototype = {
    length: 1, //长量
    selector: "", //选择器
    docList: "", //找到标签列表
    x: null,
    y: null
};
xiyuetaCss.extend = xiyuetaCss.fn.extend = function() {
    var options, name, src, copy, copyIsArray, clone,
        target = arguments[0] || {},
        i = 1,
        length = arguments.length

    if (i === length) {
        target = this;
        i--;
    }

    for (; i < length; i++) {
        if ((options = arguments[i]) != null) {
            for (name in options) {
                copy = options[name];
                if (name === "__proto__" || target === copy) {
                    continue;
                }

                if (copy !== undefined) {
                    target[name] = copy;
                }
            }
        }
    }
    return target;
};
var init = xiyuetaCss.fn.init = function(selector, x, y) {
    this.length = 0; //找到条数
    this.selector = selector; //选择器
    this.x = x;
    this.y = y;
    if (this.selector == undefined) this.selector = "[All]"; //为查的全部，因为如果为*则CSS样式里也有一个*定义
};
init.prototype = xiyuetaCss.fn;
xiyuetaCSS = $xytcss = $css = xiyuetaCss;

xiyuetaCss.fn.extend({
    css: function(param, value) { //获得或设置CSS标签参数值 
        if (value != undefined) { //设置
            _xytcss.getSetCss(this.selector, param, value);
            return this;
        } else {
            return _xytcss.getSetCss(this.selector, param);
        }
    },
    allcss: function(paramName, setParamValue) { //获得或设置CSS标签参数值 
        return _xytcss.getSetAllCss(this.selector, paramName, setParamValue);
    },
    handlecssimg: function(action, httpurl) { //处理CSS里图片
        return _xytcss.handleCssBackGround(action, httpurl);
    },
    charset: function(value) { //CSS编码
        return _xytcss.handleCssCharset(value);
    },
    parse: function(cssStyle) { //解析CSS 
        _xytcss.cssParse(cssStyle);
        return this;
    },
    config: function(configArr) { //CSS配置 
        return _xytcss.setConfig(configArr); //配置数组 
    },
    print: function(action) { //打字CSS内容 
        return _xytcss.printCss(action);
    },
    debug: function(isIE) { //调试
        return _xytcss.debug(isIE);
    }
});