String.prototype.trim = function() {
    var str = this + "";
    return str.replace(/(^\s*)|(\s*$)/g, "");
}
var _CONSOLE = function() {
    this.log = function(s) {
        if (typeof(s) == "object") {
            var c = "";
            for (var item in s) {
                var sItem = s[item] + "";
                if (sItem.indexOf("function") == -1) {
                    // response.write(item + ":  " + s[item] + '<br>');
                    var sX = s[item] + ""
                    sX = sX.replace(/</g, '&lt;').replace(/\n/g, '<br>').replace(/ /g, '&nbsp;');

                    if (typeof(s[item]) == "object") {
                        sX = this.log(s[item]);
                    }
                    if (typeof(sX) == "undefined") {
                        response.write(item + '<br>');
                    } else {
                        response.write(item + ":  " + sX + '<br>');
                    }
                }
            }
        } else {
            response.write(s + '<br>');
        }
    }
}
var console = new _CONSOLE(); //asp里调用JS没有console