
# 更新日志
  * [1.2.x](http://www.xiyueta.com/doc/changelog.asp#1-2-0)
  * [1.1.x](http://www.xiyueta.com/doc/changelog.asp#1-1-0)
  * [1.0.x](http://www.xiyueta.com/doc/changelog.asp#1-0-0)
