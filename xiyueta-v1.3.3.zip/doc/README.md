# 注意事项：
* 选择器区分大小写 如 eq(0) [name=value]，大部分浏览器均支持

# 在线文档
[http://www.xiyueta.com/](http://www.xiyueta.com/)
